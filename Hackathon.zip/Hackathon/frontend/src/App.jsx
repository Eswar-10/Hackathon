import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider } from './context/AppContext';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import WaterData from './pages/WaterData';
import CSVImport from './pages/CSVImport';
import AnomalyDetection from './pages/AnomalyDetection';
import Forecasting from './pages/Forecasting';
import BuildingComparison from './pages/BuildingComparison';
import TaskManagement from './pages/TaskManagement';
import Recommendations from './pages/Recommendations';
import Reports from './pages/Reports';
import BuildingManagement from './pages/BuildingManagement';
import UserManagement from './pages/UserManagement';
import Settings from './pages/Settings';
import Profile from './pages/Profile';

const AppContent = () => {
  const { user, loading } = useAuth();
  const [activePage, setActivePage] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-aqua-950 flex items-center justify-center text-aqua-400 font-bold text-sm">
        Initializing AquaSense AI Platform...
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard setActivePage={setActivePage} />;
      case 'water-data':
        return <WaterData />;
      case 'csv-import':
        return <CSVImport />;
      case 'anomaly-detection':
        return <AnomalyDetection setActivePage={setActivePage} />;
      case 'forecasting':
        return <Forecasting />;
      case 'building-comparison':
        return <BuildingComparison />;
      case 'task-management':
        return <TaskManagement />;
      case 'recommendations':
        return <Recommendations setActivePage={setActivePage} />;
      case 'reports':
        return <Reports />;
      case 'building-management':
        return <BuildingManagement />;
      case 'user-management':
        return <UserManagement />;
      case 'settings':
        return <Settings />;
      case 'profile':
        return <Profile />;
      default:
        return <Dashboard setActivePage={setActivePage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-aqua-950 text-slate-100">
      <Navbar activePage={activePage} setActivePage={setActivePage} />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar activePage={activePage} setActivePage={setActivePage} />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          {renderPage()}
        </main>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
};

export default App;
