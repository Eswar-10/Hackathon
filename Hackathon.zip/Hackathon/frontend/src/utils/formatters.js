export const formatLitres = (num) => {
  if (num === null || num === undefined || isNaN(num)) return '0 L';
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(2)} ML`; // Mega Litres
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(1)} kL`; // Kilo Litres
  }
  return `${Math.round(num).toLocaleString()} L`;
};

export const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  const d = new Date(dateString);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const formatShortDate = (dateString) => {
  if (!dateString) return '';
  const d = new Date(dateString);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};
