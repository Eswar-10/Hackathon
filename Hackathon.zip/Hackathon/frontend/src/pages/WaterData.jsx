import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { formatDate } from '../utils/formatters';
import { 
  Database, Plus, Search, Filter, Download, Trash2, Edit, AlertCircle, CheckCircle2 
} from 'lucide-react';

const WaterData = () => {
  const { selectedBuilding, showNotification } = useApp();
  const { isFacilityManager } = useAuth();
  const [readings, setReadings] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit] = useState(25);
  const [search, setSearch] = useState('');
  const [sourceFilter, setSourceFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);

  // Manual Entry Modal State
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    timestamp: new Date().toISOString().slice(0, 16),
    building_id: 'BLDG-001',
    consumption_litres: '',
    occupancy: 100,
    building_type: 'College',
    meter_id: 'MTR-MANUAL'
  });

  const fetchReadings = async () => {
    setLoading(true);
    try {
      const res = await API.get(`/readings?building_id=${selectedBuilding}&page=${page}&limit=${limit}&source=${sourceFilter}`);
      setReadings(res.data.readings || []);
      setTotal(res.data.total || 0);
    } catch (err) {
      showNotification('Failed to load water readings', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReadings();
  }, [selectedBuilding, page, sourceFilter]);

  const handleCreateReading = async (e) => {
    e.preventDefault();
    if (Number(formData.consumption_litres) < 0) {
      showNotification('Consumption litres cannot be negative', 'error');
      return;
    }

    try {
      await API.post('/readings', formData);
      showNotification('Manual reading saved with audit trail', 'success');
      setShowModal(false);
      setFormData({
        timestamp: new Date().toISOString().slice(0, 16),
        building_id: 'BLDG-001',
        consumption_litres: '',
        occupancy: 100,
        building_type: 'College',
        meter_id: 'MTR-MANUAL'
      });
      fetchReadings();
    } catch (err) {
      showNotification(err.response?.data?.message || 'Failed to create reading', 'error');
    }
  };

  const handleDeleteReading = async (id) => {
    if (!window.confirm('Are you sure you want to delete this water reading? An audit log entry will be created.')) return;
    try {
      await API.delete(`/readings/${id}`);
      showNotification('Reading deleted and recorded in audit log', 'info');
      fetchReadings();
    } catch (err) {
      showNotification('Failed to delete reading', 'error');
    }
  };

  const filteredReadings = readings.filter(r => 
    r.building_id.toLowerCase().includes(search.toLowerCase()) ||
    r.meter_id.toLowerCase().includes(search.toLowerCase()) ||
    r.source.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Database className="w-6 h-6 text-aqua-400" />
            Water Consumption Data Records
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Raw hourly water consumption telemetry, manual additions, and complete correction audit history.
          </p>
        </div>

        {isFacilityManager && (
          <button
            onClick={() => setShowModal(true)}
            className="px-4 py-2 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white text-xs font-semibold shadow-md shadow-aqua-600/30 transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Add Manual Reading
          </button>
        )}
      </div>

      {/* Filter & Search Bar */}
      <div className="glass-panel p-4 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search building, meter, or source..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-aqua-950/70 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-aqua-500"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs text-slate-400 font-semibold">Source:</span>
          <select
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
            className="bg-aqua-950/70 border border-slate-700 text-xs text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none"
          >
            <option value="ALL">All Data Sources</option>
            <option value="CSV_Import">CSV Import</option>
            <option value="Manual_Entry">Manual Entry</option>
            <option value="Simulated">Simulated</option>
          </select>
        </div>
      </div>

      {/* Table Container */}
      <div className="glass-panel rounded-xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-aqua-900/90 text-slate-400 font-semibold border-b border-slate-800 uppercase tracking-wider">
              <tr>
                <th className="p-3.5">Timestamp</th>
                <th className="p-3.5">Building ID</th>
                <th className="p-3.5">Type</th>
                <th className="p-3.5">Meter ID</th>
                <th className="p-3.5 text-right">Consumption (Litres)</th>
                <th className="p-3.5 text-right">Occupancy</th>
                <th className="p-3.5">Source</th>
                {isFacilityManager && <th className="p-3.5 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredReadings.map((r) => (
                <tr key={r._id} className="hover:bg-slate-800/40 transition">
                  <td className="p-3.5 font-medium text-slate-200">{formatDate(r.timestamp)}</td>
                  <td className="p-3.5 font-bold text-aqua-300">{r.building_id}</td>
                  <td className="p-3.5">{r.building_type || 'College'}</td>
                  <td className="p-3.5 font-mono text-slate-400">{r.meter_id || 'MTR-001'}</td>
                  <td className="p-3.5 text-right font-bold text-white">{r.consumption_litres.toLocaleString()} L</td>
                  <td className="p-3.5 text-right">{r.occupancy || 100}</td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                      r.source === 'CSV_Import' ? 'bg-aqua-500/20 text-aqua-300 border-aqua-500/30' :
                      r.source === 'Manual_Entry' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                      'bg-purple-500/20 text-purple-300 border-purple-500/30'
                    }`}>
                      {r.source}
                    </span>
                  </td>
                  {isFacilityManager && (
                    <td className="p-3.5 text-center">
                      <button
                        onClick={() => handleDeleteReading(r._id)}
                        className="text-slate-500 hover:text-red-400 p-1 transition"
                        title="Delete record with audit trail"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  )}
                </tr>
              ))}

              {filteredReadings.length === 0 && !loading && (
                <tr>
                  <td colSpan="8" className="p-8 text-center text-slate-400">
                    No water consumption records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 bg-aqua-950/60 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Showing {filteredReadings.length} of {total} records (Page {page})</span>
          <div className="flex space-x-2">
            <button
              disabled={page <= 1}
              onClick={() => setPage(p => p - 1)}
              className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white font-medium"
            >
              Previous
            </button>
            <button
              disabled={page * limit >= total}
              onClick={() => setPage(p => p + 1)}
              className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white font-medium"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Manual Entry Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-aqua-500/30 w-full max-w-md space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white">Add Validated Water Reading</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateReading} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Timestamp</label>
                <input
                  type="datetime-local"
                  required
                  value={formData.timestamp}
                  onChange={(e) => setFormData({ ...formData, timestamp: e.target.value })}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Building ID</label>
                <select
                  value={formData.building_id}
                  onChange={(e) => setFormData({ ...formData, building_id: e.target.value })}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                >
                  <option value="BLDG-001">BLDG-001 (Engineering Block A)</option>
                  <option value="BLDG-002">BLDG-002 (Oakwood Residency B)</option>
                  <option value="BLDG-003">BLDG-003 (Innovate Tech Park C)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Consumption (Litres)</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  required
                  placeholder="e.g. 1450"
                  value={formData.consumption_litres}
                  onChange={(e) => setFormData({ ...formData, consumption_litres: e.target.value })}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Occupancy</label>
                  <input
                    type="number"
                    min="1"
                    value={formData.occupancy}
                    onChange={(e) => setFormData({ ...formData, occupancy: e.target.value })}
                    className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Meter ID</label>
                  <input
                    type="text"
                    value={formData.meter_id}
                    onChange={(e) => setFormData({ ...formData, meter_id: e.target.value })}
                    className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                  />
                </div>
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white text-xs font-semibold shadow-md shadow-aqua-600/30"
                >
                  Save Reading
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default WaterData;
