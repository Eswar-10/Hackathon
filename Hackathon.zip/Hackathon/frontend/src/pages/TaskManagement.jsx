import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { formatDate, formatLitres } from '../utils/formatters';
import { 
  CheckSquare, ShieldCheck, Clock, User, FileText, CheckCircle2, ArrowRight, RefreshCw, AlertCircle 
} from 'lucide-react';

const TaskManagement = () => {
  const { selectedBuilding, showNotification, triggerRefresh } = useApp();
  const { isFacilityManager, user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Resolution Modal State
  const [selectedTask, setSelectedTask] = useState(null);
  const [inspectionFindings, setInspectionFindings] = useState('');
  const [actionTaken, setActionTaken] = useState('');
  const [postObservedLitres, setPostObservedLitres] = useState('');
  const [verifying, setVerifying] = useState(false);

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const res = await API.get(`/tasks?building_id=${selectedBuilding}`);
      setTasks(res.data || []);
    } catch (err) {
      showNotification('Failed to load conservation tasks', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [selectedBuilding]);

  const handleOpenResolutionModal = (task) => {
    setSelectedTask(task);
    setInspectionFindings(task.inspectionFindings || '');
    setActionTaken(task.actionTaken || '');
    setPostObservedLitres(task.postActionObservedLitres || '');
  };

  const handleResolveAndVerifyTask = async (e) => {
    e.preventDefault();
    if (!selectedTask) return;
    setVerifying(true);

    try {
      // 1. Update task with inspection details
      await API.put(`/tasks/${selectedTask._id}`, {
        inspectionFindings,
        actionTaken,
        postActionObservedLitres: Number(postObservedLitres) || undefined
      });

      // 2. Trigger automated pre/post verification engine
      const verifyRes = await API.post(`/tasks/${selectedTask._id}/verify`);

      showNotification(`Task resolved! Verified Savings: ${formatLitres(verifyRes.data.task?.verifiedSavingsLitres || 0)}`, 'success');
      setSelectedTask(null);
      fetchTasks();
      triggerRefresh();
    } catch (err) {
      showNotification(err.response?.data?.message || 'Failed to verify task savings', 'error');
    } finally {
      setVerifying(false);
    }
  };

  const handleUpdateStatus = async (taskId, newStatus) => {
    try {
      await API.put(`/tasks/${taskId}`, { status: newStatus });
      showNotification(`Task status updated to ${newStatus}`, 'info');
      fetchTasks();
    } catch (err) {
      showNotification('Failed to update status', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-emerald-400" />
            Alert-to-Action-to-Verification Task Workflow
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Tracks inspection findings, plumbing actions taken, and quantifies pre-repair vs post-repair verified water savings.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-3 py-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="text-xs text-emerald-300 font-bold">Automated Verification Active</span>
        </div>
      </div>

      {/* Task Kanban / Cards List */}
      <div className="space-y-4">
        {tasks.map((t) => (
          <div key={t._id} className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4 hover:border-aqua-500/40 transition">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono font-bold text-aqua-400">{t.task_id}</span>
                  <span className="text-xs font-semibold text-slate-400">({t.building_id})</span>
                  <StatusBadge status={t.status} />
                </div>
                <h3 className="text-base font-extrabold text-white mt-1">{t.title}</h3>
              </div>

              {t.verifiedSavingsLitres > 0 && (
                <div className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-extrabold flex items-center gap-1.5 glow-teal">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Verified Savings: {formatLitres(t.verifiedSavingsLitres)} / day
                </div>
              )}
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{t.description}</p>

            {/* Inspection Findings & Verified Pre/Post Baseline Box */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-aqua-950/70 border border-slate-800 space-y-1">
                <p className="text-[11px] font-bold uppercase text-slate-400 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-aqua-400" /> Inspection Findings & Repair Log:
                </p>
                <p className="text-xs text-slate-200 italic">
                  "{t.inspectionFindings || 'Inspection pending facility manager review.'}"
                </p>
                {t.actionTaken && (
                  <p className="text-xs text-emerald-400 font-semibold mt-1">
                    Action Taken: {t.actionTaken}
                  </p>
                )}
              </div>

              <div className="p-3.5 rounded-xl bg-aqua-950/70 border border-slate-800 grid grid-cols-2 gap-2 text-center">
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Pre-Action Baseline</p>
                  <p className="text-sm font-extrabold text-red-400 mt-1">
                    {t.preActionBaselineLitres ? `${t.preActionBaselineLitres.toLocaleString()} L` : 'N/A'}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Post-Action Observed</p>
                  <p className="text-sm font-extrabold text-emerald-400 mt-1">
                    {t.postActionObservedLitres ? `${t.postActionObservedLitres.toLocaleString()} L` : 'N/A'}
                  </p>
                </div>
              </div>
            </div>

            {/* Workflow Action Bar */}
            <div className="pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-400">
              <div className="flex items-center space-x-4">
                <span>Assigned To: <strong className="text-slate-200">{t.assignedToName || 'Unassigned'}</strong></span>
                <span>Priority: <strong className="text-amber-400">{t.priority}</strong></span>
              </div>

              {isFacilityManager && (
                <div className="flex items-center space-x-2">
                  {t.status === 'Open' && (
                    <button
                      onClick={() => handleUpdateStatus(t._id, 'In Progress')}
                      className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
                    >
                      Start Task (In Progress)
                    </button>
                  )}

                  {t.status !== 'Resolved' && t.status !== 'Closed' && (
                    <button
                      onClick={() => handleOpenResolutionModal(t)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Resolve & Verify Savings
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {tasks.length === 0 && !loading && (
          <div className="p-12 glass-panel rounded-2xl text-center text-slate-400">
            <CheckSquare className="w-12 h-12 text-emerald-400 mx-auto mb-3 opacity-60" />
            <h3 className="text-base font-bold text-white">No Conservation Tasks Logged</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
              Create a task from the Anomaly Detection tab when anomalous consumption is flagged.
            </p>
          </div>
        )}
      </div>

      {/* Resolution & Savings Verification Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-emerald-500/40 w-full max-w-md space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                Resolve Task & Verify Savings
              </h3>
              <button onClick={() => setSelectedTask(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleResolveAndVerifyTask} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Inspection Findings</label>
                <textarea
                  required
                  rows="2"
                  placeholder="e.g. Discovered running toilet flapper valve on 2nd floor restroom causing 500L/hr continuous leak."
                  value={inspectionFindings}
                  onChange={(e) => setInspectionFindings(e.target.value)}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Plumbing Repair Action Taken</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Replaced rubber diaphragm and tightened main shutoff valve."
                  value={actionTaken}
                  onChange={(e) => setActionTaken(e.target.value)}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Post-Repair Observed Daily Consumption (Litres)
                </label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 14200"
                  value={postObservedLitres}
                  onChange={(e) => setPostObservedLitres(e.target.value)}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Pre-Action Baseline: <strong>{selectedTask.preActionBaselineLitres || 18500} L</strong>
                </p>
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setSelectedTask(null)}
                  className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={verifying}
                  className="flex-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold shadow-md shadow-emerald-600/30 flex items-center justify-center gap-1"
                >
                  {verifying ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                  {verifying ? 'Calculating Impact...' : 'Verify Savings & Resolve'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskManagement;
