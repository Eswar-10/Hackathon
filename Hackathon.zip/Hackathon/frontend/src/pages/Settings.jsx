import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { Settings as SettingsIcon, Save, Bell, Globe } from 'lucide-react';

const Settings = () => {
  const { showNotification } = useApp();
  const [settings, setSettings] = useState({
    orgName: 'AquaSense AI Enterprise',
    defaultLpcdTarget: 135,
    defaultNightFlowThresholdPct: 30,
    alertEmailNotifications: true,
    unitPreference: 'Litres'
  });

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await API.get('/settings');
        if (res.data) setSettings(res.data);
      } catch (err) {
        console.error('Failed to load settings:', err);
      }
    };

    fetchSettings();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.put('/settings', settings);
      showNotification('Organization settings updated successfully', 'success');
    } catch (err) {
      showNotification('Failed to update settings', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-3xl">
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20">
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <SettingsIcon className="w-6 h-6 text-aqua-400" />
          Organization System Settings
        </h2>
        <p className="text-xs text-slate-400 mt-1">Configure global benchmarks, notification rules, and unit preferences.</p>
      </div>

      <form onSubmit={handleSubmit} className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">Organization Name</label>
          <input
            type="text"
            value={settings.orgName}
            onChange={(e) => setSettings({ ...settings, orgName: e.target.value })}
            className="w-full p-2.5 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Default LPCD Target (L)</label>
            <input
              type="number"
              value={settings.defaultLpcdTarget}
              onChange={(e) => setSettings({ ...settings, defaultLpcdTarget: Number(e.target.value) })}
              className="w-full p-2.5 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Night Flow Deviation Alert %</label>
            <input
              type="number"
              value={settings.defaultNightFlowThresholdPct}
              onChange={(e) => setSettings({ ...settings, defaultNightFlowThresholdPct: Number(e.target.value) })}
              className="w-full p-2.5 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
            />
          </div>
        </div>

        <div className="flex items-center space-x-3 pt-2">
          <input
            type="checkbox"
            id="notifications"
            checked={settings.alertEmailNotifications}
            onChange={(e) => setSettings({ ...settings, alertEmailNotifications: e.target.checked })}
            className="w-4 h-4 text-aqua-600 rounded bg-slate-900 border-slate-700 focus:ring-aqua-500"
          />
          <label htmlFor="notifications" className="text-xs font-semibold text-slate-300">
            Enable Email & System Alert Notifications for Critical Anomalies
          </label>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white font-bold text-xs shadow-md shadow-aqua-600/30 flex items-center gap-1.5"
          >
            <Save className="w-4 h-4" /> Save Organization Settings
          </button>
        </div>
      </form>
    </div>
  );
};

export default Settings;
