import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { AlertBadge } from '../components/StatusBadge';
import { formatDate } from '../utils/formatters';
import { 
  AlertTriangle, Play, ShieldAlert, Cpu, Sparkles, ArrowRight, CheckSquare, RefreshCw, Sliders 
} from 'lucide-react';

const AnomalyDetection = ({ setActivePage }) => {
  const { selectedBuilding, showNotification, triggerRefresh } = useApp();
  const { isFacilityManager } = useAuth();
  const [alerts, setAlerts] = useState([]);
  const [thresholdPct, setThresholdPct] = useState(30);
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [dataQuality, setDataQuality] = useState(null);

  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const res = await API.get(`/anomalies/alerts?building_id=${selectedBuilding}&severity=${severityFilter}`);
      setAlerts(res.data || []);
    } catch (err) {
      showNotification('Failed to load anomaly alerts', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, [selectedBuilding, severityFilter]);

  const handleRunDetection = async () => {
    setRunning(true);
    try {
      const res = await API.post('/anomalies/detect', {
        building_id: selectedBuilding,
        threshold_pct: Number(thresholdPct)
      });
      setDataQuality(res.data.dataQuality || null);
      showNotification(`Anomaly engine run complete: ${res.data.totalAnomaliesDetected} anomalies detected`, 'success');
      fetchAlerts();
      triggerRefresh();
    } catch (err) {
      showNotification(err.response?.data?.message || 'Failed to execute anomaly engine', 'error');
    } finally {
      setRunning(false);
    }
  };

  const handleCreateTaskForAlert = async (alert) => {
    try {
      await API.post('/tasks', {
        alert_id: alert.alert_id,
        building_id: alert.building_id,
        title: `Investigate ${alert.severity} Anomaly at ${alert.building_id}`,
        description: `Observed ${alert.observed_consumption}L vs expected ${alert.expected_consumption}L (+${alert.percentage_deviation}% deviation). ${alert.recommended_action}`,
        priority: alert.severity,
        assignedByName: 'System Trigger'
      });
      showNotification(`Conservation Task created for Alert ${alert.alert_id}`, 'success');
      setActivePage('task-management');
    } catch (err) {
      showNotification('Failed to create task for alert', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-amber-400" />
            Explainable Water Anomaly Detection Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Hybrid detection: validated readings + rule-based safeguards, with Isolation Forest as supporting evidence when enough history exists. An alert indicates unusual consumption, not a confirmed leak.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-aqua-950/70 border border-slate-700 rounded-lg px-3 py-1.5">
            <Sliders className="w-4 h-4 text-aqua-400" />
            <span className="text-xs text-slate-300 font-semibold">Dev Threshold:</span>
            <select
              value={thresholdPct}
              onChange={(e) => setThresholdPct(e.target.value)}
              className="bg-transparent text-xs text-white font-bold focus:outline-none"
            >
              <option value="20" className="bg-aqua-900">+20% Sensitive</option>
              <option value="30" className="bg-aqua-900">+30% Standard</option>
              <option value="50" className="bg-aqua-900">+50% High Strict</option>
            </select>
          </div>

          <button
            onClick={handleRunDetection}
            disabled={running}
            className="px-4 py-2 rounded-lg bg-gradient-to-r from-amber-600 to-aqua-500 text-white text-xs font-bold shadow-lg shadow-amber-600/30 hover:opacity-90 transition flex items-center gap-1.5"
          >
            {running ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {running ? 'Running Engine...' : 'Run Detection Engine'}
          </button>
        </div>
      </div>

      {dataQuality && (
        <div className="glass-panel p-4 rounded-xl border border-slate-700 space-y-2">
          <h3 className="text-sm font-bold text-white">Reading Quality Summary</h3>
          <p className="text-xs text-slate-300">
            Valid rows: {dataQuality.valid_rows ?? '—'} / {dataQuality.total_rows ?? '—'} ·
            Invalid: {dataQuality.invalid_rows ?? 0} · Duplicates: {dataQuality.duplicate_rows ?? 0} ·
            Large time gaps: {dataQuality.missing_interval_gaps ?? 0}
          </p>
          {!dataQuality.live_feed_connected && (
            <p className="text-xs text-amber-300">No live meter feed is connected in this run. Imported, manual, or simulated readings are analyzed as historical data; live staleness checks activate for Meter_API, Meter_Gateway, or Live_Meter sources.</p>
          )}
          {(dataQuality.stale_live_meters || []).length > 0 && (
            <p className="text-xs text-amber-300">Stale live meters: {dataQuality.stale_live_meters.map(m => `${m.building_id}/${m.meter_id}`).join(', ')}</p>
          )}
        </div>
      )}

      {/* Severity Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
        {['ALL', 'Critical', 'High', 'Medium', 'Low'].map((sev) => (
          <button
            key={sev}
            onClick={() => setSeverityFilter(sev)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              severityFilter === sev
                ? 'bg-aqua-600 text-white shadow'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {sev === 'ALL' ? 'All Severities' : `${sev} Severity`}
          </button>
        ))}
      </div>

      {/* Explainable Anomaly Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {alerts.map((alt) => (
          <div key={alt.alert_id} className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-4 hover:border-aqua-500/40 transition">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-aqua-300 font-mono">{alt.alert_id}</span>
                <h3 className="text-base font-extrabold text-white">{alt.building_id} - {alt.anomaly_type}</h3>
              </div>
              <AlertBadge severity={alt.severity} />
            </div>

            <p className="text-xs text-slate-400">Timestamp: <strong>{formatDate(alt.timestamp)}</strong></p>

            {/* Evidence Comparison Box */}
            <div className="p-3 rounded-xl bg-aqua-950/70 border border-slate-800 grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Observed Draw</p>
                <p className="text-base font-extrabold text-red-400">{alt.observed_consumption} L</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Baseline Expected</p>
                <p className="text-base font-extrabold text-slate-300">{alt.expected_consumption} L</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Deviation</p>
                <p className="text-base font-extrabold text-amber-400">
                  +{alt.percentage_deviation}%
                </p>
              </div>
            </div>

            {/* Contributing Factors Breakdown */}
            <div>
              <p className="text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-aqua-400" />
                Contributing Explainable Factors:
              </p>
              <ul className="space-y-1">
                {alt.contributing_factors?.map((f, i) => (
                  <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                    <span className="text-aqua-400 font-bold">•</span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommended Action */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30">
              <p className="text-[11px] font-bold text-amber-300 uppercase">Recommended Next Action:</p>
              <p className="text-xs text-slate-200 mt-0.5">{alt.recommended_action}</p>
            </div>

            {/* Action Bar */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
              <span className="text-[11px] font-semibold text-slate-400">
                Detection: <strong className="text-aqua-300">{alt.detection_method || 'legacy alert'}</strong>
              </span>

              {isFacilityManager && (
                <button
                  onClick={() => handleCreateTaskForAlert(alt)}
                  className="px-3 py-1.5 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white text-xs font-bold shadow transition flex items-center gap-1"
                >
                  <CheckSquare className="w-3.5 h-3.5" /> Take Action (Create Task)
                </button>
              )}
            </div>
          </div>
        ))}

        {alerts.length === 0 && !loading && (
          <div className="col-span-2 p-12 glass-panel rounded-2xl text-center text-slate-400">
            <ShieldAlert className="w-12 h-12 text-aqua-400 mx-auto mb-3 opacity-60" />
            <h3 className="text-base font-bold text-white">No Anomaly Alerts Detected</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
              Click "Run Detection Engine" above to trigger multi-factor baseline evaluation on current water readings.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnomalyDetection;
