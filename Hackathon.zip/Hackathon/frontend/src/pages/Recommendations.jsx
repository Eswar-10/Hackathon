import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { formatLitres } from '../utils/formatters';
import { 
  Sparkles, Lightbulb, ShieldCheck, ArrowRight, TrendingDown, DollarSign 
} from 'lucide-react';

const Recommendations = ({ setActivePage }) => {
  const { selectedBuilding } = useApp();
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecommendations = async () => {
      setLoading(true);
      try {
        const res = await API.get(`/recommendations?building_id=${selectedBuilding}`);
        setRecommendations(res.data || []);
      } catch (err) {
        console.error('Failed to load recommendations:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchRecommendations();
  }, [selectedBuilding]);

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20">
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-aqua-400" />
          AI-Driven Water Conservation Recommendations
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Rule-based & baseline-backed recommendations with evidence, estimated savings, and verification methods.
        </p>
      </div>

      {/* Recommendations Cards Grid */}
      <div className="space-y-4">
        {recommendations.map((rec) => (
          <div key={rec.id} className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4 hover:border-aqua-500/40 transition">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-aqua-500/20 border border-aqua-500/30 flex items-center justify-center text-aqua-300 shrink-0">
                  <Lightbulb className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-aqua-400">{rec.building_id}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300">
                      {rec.category}
                    </span>
                  </div>
                  <h3 className="text-base font-extrabold text-white mt-0.5">{rec.title}</h3>
                </div>
              </div>

              <div className="text-right">
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Est. Potential Savings</p>
                <p className="text-base font-extrabold text-emerald-400">{rec.estimatedSavings}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{rec.description}</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 rounded-xl bg-aqua-950/70 border border-slate-800 space-y-1">
                <p className="text-[11px] font-bold text-slate-400 uppercase">Supporting Evidence:</p>
                <p className="text-xs text-slate-200">{rec.evidence}</p>
              </div>
              <div className="p-3 rounded-xl bg-aqua-950/70 border border-slate-800 space-y-1">
                <p className="text-[11px] font-bold text-slate-400 uppercase">Verification Strategy:</p>
                <p className="text-xs text-slate-200">{rec.verificationMethod}</p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-xs text-slate-400">
              <span>Financial Return: <strong className="text-emerald-300">{rec.estimatedFinancialReturn}</strong></span>
              <button
                onClick={() => setActivePage('task-management')}
                className="px-3 py-1.5 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white font-bold text-xs flex items-center gap-1 shadow"
              >
                Log Action Plan <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Recommendations;
