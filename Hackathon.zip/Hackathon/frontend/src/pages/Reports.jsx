import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { exportToCSV } from '../utils/csvExport';
import { formatDate, formatLitres } from '../utils/formatters';
import { 
  FileText, Download, Printer, ShieldCheck, CheckCircle2, Info, Calculator 
} from 'lucide-react';

const Reports = () => {
  const { selectedBuilding } = useApp();
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReport = async () => {
      setLoading(true);
      try {
        const res = await API.get(`/reports?building_id=${selectedBuilding}`);
        setReport(res.data);
      } catch (err) {
        console.error('Failed to load report:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchReport();
  }, [selectedBuilding]);

  const handleExportCSV = () => {
    if (!report) return;
    const summaryData = [
      {
        ReportTitle: report.reportTitle,
        BuildingFilter: report.buildingFilter,
        GeneratedAt: report.generatedAt,
        TotalConsumptionLitres: report.summary.totalConsumptionLitres,
        TotalConsumptionKilolitres: report.summary.totalConsumptionKilolitres,
        AvgDailyConsumptionLitres: report.summary.avgDailyConsumptionLitres,
        TotalAnomaliesDetected: report.summary.totalAnomaliesDetected,
        ResolvedTasksCount: report.summary.resolvedTasksCount,
        TotalVerifiedSavingsLitres: report.summary.totalVerifiedSavingsLitres,
        EstimatedFinancialSavingsINR: report.summary.estimatedCostSavingsINR
      }
    ];
    exportToCSV(`aquasense_impact_report_${Date.now()}.csv`, summaryData);
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading || !report) {
    return (
      <div className="p-12 text-center text-xs text-slate-400">
        Generating AquaSense Impact Report...
      </div>
    );
  }

  const { summary } = report;

  return (
    <div className="space-y-6 pb-12 print:p-0">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <FileText className="w-6 h-6 text-aqua-400" />
            Executive Water Impact & Conservation Report
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Quantified water intelligence, verified leak repair savings, and transparent formula benchmarks.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-aqua-300 border border-aqua-500/30 text-xs font-semibold transition flex items-center gap-1.5"
          >
            <Download className="w-4 h-4 text-aqua-400" /> Export Summary CSV
          </button>
          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded-lg bg-gradient-to-r from-aqua-600 to-aqua-500 text-white text-xs font-bold shadow-lg shadow-aqua-600/30 hover:opacity-90 transition flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" /> Print / Save PDF
          </button>
        </div>
      </div>

      {/* Printable Report Document Container */}
      <div className="glass-panel p-8 rounded-2xl border border-slate-800 space-y-6 bg-aqua-950/90 print:bg-white print:text-black print:border-none">
        {/* Printable Header */}
        <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-black text-white print:text-black">{report.reportTitle}</h1>
            <p className="text-xs text-slate-400 print:text-gray-600">
              Filter Scope: <strong>{report.buildingFilter}</strong> | Period: {report.timePeriodDays} days
            </p>
          </div>
          <div className="text-right text-xs text-slate-400 print:text-gray-600">
            <p>Generated On: {formatDate(report.generatedAt)}</p>
            <p className="text-emerald-400 font-bold print:text-green-700">Audit Status: Verified</p>
          </div>
        </div>

        {/* Executive Summary Numbers */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-aqua-900/60 border border-slate-800 print:bg-gray-100 print:border-gray-300">
            <p className="text-[10px] font-bold uppercase text-slate-400 print:text-gray-600">Total Consumption</p>
            <p className="text-xl font-extrabold text-white print:text-black mt-1">
              {summary.totalConsumptionKilolitres} kL
            </p>
            <p className="text-[10px] text-slate-400">({summary.totalConsumptionLitres.toLocaleString()} L)</p>
          </div>

          <div className="p-4 rounded-xl bg-aqua-900/60 border border-slate-800 print:bg-gray-100 print:border-gray-300">
            <p className="text-[10px] font-bold uppercase text-slate-400 print:text-gray-600">Avg Daily Volume</p>
            <p className="text-xl font-extrabold text-aqua-300 print:text-blue-700 mt-1">
              {formatLitres(summary.avgDailyConsumptionLitres)}
            </p>
            <p className="text-[10px] text-slate-400">Normalized daily draw</p>
          </div>

          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 print:bg-green-50 print:border-green-300">
            <p className="text-[10px] font-bold uppercase text-slate-300 print:text-gray-600">Verified Water Saved</p>
            <p className="text-xl font-extrabold text-emerald-300 print:text-green-800 mt-1">
              {formatLitres(summary.totalVerifiedSavingsLitres)}
            </p>
            <p className="text-[10px] text-emerald-400 font-semibold">{summary.resolvedTasksCount} Actioned Repairs</p>
          </div>

          <div className="p-4 rounded-xl bg-aqua-900/60 border border-slate-800 print:bg-gray-100 print:border-gray-300">
            <p className="text-[10px] font-bold uppercase text-slate-400 print:text-gray-600">Est. Financial Offset</p>
            <p className="text-xl font-extrabold text-white print:text-black mt-1">
              ₹{summary.estimatedCostSavingsINR.toLocaleString()}
            </p>
            <p className="text-[10px] text-slate-400">Tariff & energy savings</p>
          </div>
        </div>

        {/* Formulas & Methodology Callout */}
        <div className="p-4 rounded-xl bg-aqua-950 border border-slate-800 space-y-2 print:bg-gray-50 print:border-gray-200">
          <h3 className="text-xs font-bold text-aqua-400 print:text-blue-800 flex items-center gap-1.5">
            <Calculator className="w-4 h-4" /> Formulas & Calculation Assumptions
          </h3>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-1 text-[11px] text-slate-300 print:text-gray-700">
            {report.formulasAndAssumptions?.map((f, i) => (
              <li key={i} className="flex items-center gap-1">
                <span className="text-aqua-400 font-bold">•</span> {f}
              </li>
            ))}
          </ul>
        </div>

        {/* Verified Conservation Actions Table */}
        <div>
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 print:text-gray-800">
            Actioned Conservation Tasks & Verified Impact Log
          </h3>
          <div className="overflow-x-auto rounded-lg border border-slate-800 print:border-gray-300">
            <table className="w-full text-left text-xs text-slate-300 print:text-black">
              <thead className="bg-aqua-900/90 text-slate-400 font-semibold border-b border-slate-800 print:bg-gray-200 print:text-gray-800">
                <tr>
                  <th className="p-2.5">Task ID</th>
                  <th className="p-2.5">Building</th>
                  <th className="p-2.5">Title</th>
                  <th className="p-2.5">Repair Action Taken</th>
                  <th className="p-2.5 text-right">Verified Daily Savings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 print:divide-gray-200">
                {report.completedTasks?.map((t) => (
                  <tr key={t.task_id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-mono font-bold text-aqua-300 print:text-blue-800">{t.task_id}</td>
                    <td className="p-2.5">{t.building_id}</td>
                    <td className="p-2.5 font-medium text-white print:text-black">{t.title}</td>
                    <td className="p-2.5">{t.actionTaken || 'Plumbing valve replacement'}</td>
                    <td className="p-2.5 text-right font-bold text-emerald-400 print:text-green-700">
                      +{formatLitres(t.verifiedSavingsLitres)} / day
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
