import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { 
  Building, Plus, Edit, Trash2, Sliders, Users, DoorOpen, Home 
} from 'lucide-react';

const BuildingManagement = () => {
  const { buildings, showNotification, triggerRefresh } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editBuilding, setEditBuilding] = useState(null);

  const [formData, setFormData] = useState({
    building_id: '',
    name: '',
    building_type: 'College',
    address: '',
    occupantCount: 100,
    occupiedRooms: 25,
    totalRooms: 30,
    areaSqFt: 15000,
    expectedDailyLitres: 13500,
    lpcdTarget: 135
  });

  const handleOpenAdd = () => {
    setEditBuilding(null);
    setFormData({
      building_id: `BLDG-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      building_type: 'College',
      address: '',
      occupantCount: 100,
      occupiedRooms: 25,
      totalRooms: 30,
      areaSqFt: 15000,
      expectedDailyLitres: 13500,
      lpcdTarget: 135
    });
    setShowModal(true);
  };

  const handleOpenEdit = (b) => {
    setEditBuilding(b);
    setFormData({
      building_id: b.building_id,
      name: b.name,
      building_type: b.building_type,
      address: b.address || '',
      occupantCount: b.occupantCount,
      occupiedRooms: b.occupiedRooms,
      totalRooms: b.totalRooms,
      areaSqFt: b.areaSqFt,
      expectedDailyLitres: b.baselineThresholds?.expectedDailyLitres || 15000,
      lpcdTarget: b.baselineThresholds?.lpcdTarget || 135
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editBuilding) {
        await API.put(`/buildings/${editBuilding._id}`, {
          ...formData,
          baselineThresholds: {
            expectedDailyLitres: Number(formData.expectedDailyLitres),
            lpcdTarget: Number(formData.lpcdTarget)
          }
        });
        showNotification('Building threshold profile updated', 'success');
      } else {
        await API.post('/buildings', {
          ...formData,
          baselineThresholds: {
            expectedDailyLitres: Number(formData.expectedDailyLitres),
            lpcdTarget: Number(formData.lpcdTarget)
          }
        });
        showNotification('New building added to AquaSense AI', 'success');
      }
      setShowModal(false);
      triggerRefresh();
    } catch (err) {
      showNotification(err.response?.data?.message || 'Failed to save building', 'error');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this building?')) return;
    try {
      await API.delete(`/buildings/${id}`);
      showNotification('Building deleted', 'info');
      triggerRefresh();
    } catch (err) {
      showNotification('Failed to delete building', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Building className="w-6 h-6 text-aqua-400" />
            Building Facility & Threshold Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">Configure occupant numbers, area sq ft, and expected baseline thresholds.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white text-xs font-bold shadow-md shadow-aqua-600/30 flex items-center gap-1"
        >
          <Plus className="w-4 h-4" /> Add Building
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {buildings.map((b) => (
          <div key={b._id} className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-aqua-400">{b.building_id}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-aqua-500/20 text-aqua-300">
                {b.building_type}
              </span>
            </div>

            <h3 className="text-base font-extrabold text-white">{b.name}</h3>
            <p className="text-xs text-slate-400">{b.address || 'Campus Location'}</p>

            <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
              <div className="p-2 rounded bg-aqua-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">Occupants:</span>
                <strong className="text-white">{b.occupantCount}</strong>
              </div>
              <div className="p-2 rounded bg-aqua-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">Target LPCD:</span>
                <strong className="text-aqua-300">{b.baselineThresholds?.lpcdTarget || 135} L</strong>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-end space-x-2">
              <button onClick={() => handleOpenEdit(b)} className="p-1.5 text-slate-400 hover:text-aqua-300">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleDelete(b._id)} className="p-1.5 text-slate-400 hover:text-red-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-aqua-500/40 w-full max-w-md space-y-4">
            <h3 className="text-base font-bold text-white">
              {editBuilding ? 'Edit Building Thresholds' : 'Add New Building'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Building ID</label>
                <input
                  type="text"
                  required
                  value={formData.building_id}
                  onChange={(e) => setFormData({ ...formData, building_id: e.target.value })}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Building Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Science Block C"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Building Type</label>
                  <select
                    value={formData.building_type}
                    onChange={(e) => setFormData({ ...formData, building_type: e.target.value })}
                    className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                  >
                    <option value="College">College</option>
                    <option value="Apartment">Apartment</option>
                    <option value="Commercial">Commercial</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Occupant Count</label>
                  <input
                    type="number"
                    required
                    value={formData.occupantCount}
                    onChange={(e) => setFormData({ ...formData, occupantCount: e.target.value })}
                    className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Expected Daily (L)</label>
                  <input
                    type="number"
                    value={formData.expectedDailyLitres}
                    onChange={(e) => setFormData({ ...formData, expectedDailyLitres: e.target.value })}
                    className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Target LPCD (L)</label>
                  <input
                    type="number"
                    value={formData.lpcdTarget}
                    onChange={(e) => setFormData({ ...formData, lpcdTarget: e.target.value })}
                    className="w-full p-2 bg-aqua-950/80 border border-slate-700 rounded-lg text-xs text-white"
                  />
                </div>
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-lg bg-aqua-600 hover:bg-aqua-500 text-white text-xs font-bold"
                >
                  Save Building
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BuildingManagement;
