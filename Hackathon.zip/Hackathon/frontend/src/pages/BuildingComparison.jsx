import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { formatLitres } from '../utils/formatters';
import { 
  GitCompare, Building2, Users, Award, ShieldCheck, ArrowUpRight 
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend 
} from 'recharts';

const BuildingComparison = () => {
  const [comparison, setComparison] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchComparison = async () => {
      setLoading(true);
      try {
        const res = await API.get('/comparison');
        setComparison(res.data || []);
      } catch (err) {
        console.error('Failed to fetch comparison data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchComparison();
  }, []);

  const chartData = comparison.map(b => ({
    name: b.name.slice(0, 15),
    lpcd: b.lpcd,
    target: b.lpcdTarget || 135,
    dailyLitres: Math.round(b.avgDailyLitres)
  }));

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20">
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <GitCompare className="w-6 h-6 text-aqua-400" />
          Fair Normalized Building Water Comparison
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Normalizes water usage by Litres Per Capita Per Day (LPCD) and occupied room count for fair benchmarking across different building types.
        </p>
      </div>

      {/* Comparison Chart */}
      <div className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Building2 className="w-4 h-4 text-aqua-400" />
          Normalized LPCD Draw vs Target Benchmarks
        </h3>

        <div className="h-72 w-full">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E3E62" opacity={0.5} />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0B192C', borderColor: '#1E3E62', color: '#fff', borderRadius: '8px' }}
                />
                <Legend />
                <Bar dataKey="lpcd" fill="#00A896" name="Observed LPCD (L/person/day)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="target" fill="#00D26A" name="Target LPCD Benchmark" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-slate-400">
              Loading building comparison metrics...
            </div>
          )}
        </div>
      </div>

      {/* Building Comparison Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {comparison.map((b) => (
          <div key={b.building_id} className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-4 hover:border-aqua-500/40 transition">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-aqua-300 font-mono">{b.building_id}</span>
                <h3 className="text-base font-extrabold text-white">{b.name}</h3>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-aqua-500/20 text-aqua-300 border border-aqua-500/30">
                {b.building_type}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-aqua-950/70 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Observed LPCD:</span>
                <strong className={`text-sm ${b.lpcd > b.lpcdTarget ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {b.lpcd} L/person/day
                </strong>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Target LPCD:</span>
                <span className="font-semibold text-slate-300">{b.lpcdTarget} L/person/day</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Avg Daily Volume:</span>
                <span className="font-bold text-white">{formatLitres(b.avgDailyLitres)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center text-xs text-slate-400">
              <div className="p-2 rounded bg-slate-900/60 border border-slate-800">
                <p className="text-[10px] uppercase font-semibold">Occupants</p>
                <p className="text-sm font-bold text-white mt-0.5">{b.occupants}</p>
              </div>
              <div className="p-2 rounded bg-slate-900/60 border border-slate-800">
                <p className="text-[10px] uppercase font-semibold">Occupied Rooms</p>
                <p className="text-sm font-bold text-white mt-0.5">{b.occupiedRooms}</p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Data Completeness:</span>
              <span className="font-bold text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> {b.dataCompletenessPct}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BuildingComparison;
