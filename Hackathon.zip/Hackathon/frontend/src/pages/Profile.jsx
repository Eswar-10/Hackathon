import React from 'react';
import { useAuth } from '../context/AuthContext';
import { UserCircle, ShieldCheck, Mail, Building2, MapPin } from 'lucide-react';

const Profile = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6 pb-12 max-w-2xl">
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20">
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <UserCircle className="w-6 h-6 text-aqua-400" />
          User Profile & Account Information
        </h2>
        <p className="text-xs text-slate-400 mt-1">Authorized access rights and assigned building scopes.</p>
      </div>

      <div className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4">
        <div className="flex items-center space-x-4 border-b border-slate-800 pb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-aqua-600 to-aqua-400 flex items-center justify-center text-white font-extrabold text-2xl border-2 border-aqua-400">
            {user?.name ? user.name.charAt(0) : 'U'}
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">{user?.name || 'User'}</h3>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-aqua-500/20 text-aqua-300 border border-aqua-500/30">
              {user?.role || 'Viewer'}
            </span>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-300">
          <div className="flex items-center space-x-3">
            <Mail className="w-4 h-4 text-slate-400" />
            <span>Email Address: <strong className="text-white font-mono">{user?.email}</strong></span>
          </div>
          <div className="flex items-center space-x-3">
            <Building2 className="w-4 h-4 text-slate-400" />
            <span>Department: <strong className="text-white">{user?.department || 'Operations'}</strong></span>
          </div>
          <div className="flex items-center space-x-3">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Assigned Buildings Scope: <strong className="text-aqua-300">BLDG-001, BLDG-002, BLDG-003</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
