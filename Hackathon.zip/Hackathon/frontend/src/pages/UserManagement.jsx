import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { formatDate } from '../utils/formatters';
import { Users, ShieldCheck, Trash2, UserPlus, Key } from 'lucide-react';

const UserManagement = () => {
  const { showNotification } = useApp();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await API.get('/users');
      setUsers(res.data || []);
    } catch (err) {
      showNotification('Failed to load user accounts', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleRoleChange = async (userId, newRole) => {
    try {
      await API.put(`/users/${userId}/role`, { role: newRole });
      showNotification(`Role updated to ${newRole}`, 'success');
      fetchUsers();
    } catch (err) {
      showNotification('Failed to update user role', 'error');
    }
  };

  const handleDeleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      await API.delete(`/users/${userId}`);
      showNotification('User account deleted', 'info');
      fetchUsers();
    } catch (err) {
      showNotification('Failed to delete user', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-aqua-400" />
            System User Management & Role Authorization
          </h2>
          <p className="text-xs text-slate-400 mt-1">Manage platform access privileges: Administrator, Facility Manager, and Viewer.</p>
        </div>
      </div>

      <div className="glass-panel rounded-xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-aqua-900/90 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3.5">Name</th>
                <th className="p-3.5">Email</th>
                <th className="p-3.5">Role</th>
                <th className="p-3.5">Department</th>
                <th className="p-3.5">Joined Date</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {users.map((u) => (
                <tr key={u._id} className="hover:bg-slate-800/40">
                  <td className="p-3.5 font-bold text-white flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-slate-800 text-aqua-300 font-bold flex items-center justify-center border border-aqua-500/30">
                      {u.name.charAt(0)}
                    </div>
                    {u.name}
                  </td>
                  <td className="p-3.5 text-slate-300 font-mono">{u.email}</td>
                  <td className="p-3.5">
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u._id, e.target.value)}
                      className="bg-aqua-950/80 border border-slate-700 text-xs text-white rounded p-1"
                    >
                      <option value="Administrator">Administrator</option>
                      <option value="Facility Manager">Facility Manager</option>
                      <option value="Viewer">Viewer</option>
                    </select>
                  </td>
                  <td className="p-3.5">{u.department || 'Operations'}</td>
                  <td className="p-3.5">{formatDate(u.createdAt)}</td>
                  <td className="p-3.5 text-center">
                    <button onClick={() => handleDeleteUser(u._id)} className="text-slate-500 hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
