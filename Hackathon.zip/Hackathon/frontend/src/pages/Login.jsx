import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Droplets, Lock, Mail, ShieldCheck, UserCheck, Eye } from 'lucide-react';

const Login = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState('admin@aquasense.ai');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await login(email, password);
    setLoading(false);
    if (!res.success) {
      setError(res.message);
    }
  };

  const setRoleDemo = (roleEmail, rolePass) => {
    setEmail(roleEmail);
    setPassword(rolePass);
  };

  return (
    <div className="min-h-screen bg-aqua-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background ambient lighting effects */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-aqua-600/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-md glass-panel p-8 rounded-2xl border border-aqua-500/20 shadow-2xl relative z-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-aqua-600 to-aqua-400 flex items-center justify-center mx-auto mb-4 shadow-xl shadow-aqua-600/30">
            <Droplets className="w-9 h-9 text-white animate-pulse" />
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">AquaSense AI</h2>
          <p className="text-xs text-slate-400 mt-1">Explainable Water Intelligence & Conservation Platform</p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-semibold text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-aqua-900/60 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-aqua-500 transition"
                placeholder="user@aquasense.ai"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-aqua-900/60 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-aqua-500 transition"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-gradient-to-r from-aqua-600 to-aqua-500 text-white font-semibold text-sm shadow-lg shadow-aqua-600/30 hover:opacity-90 transition duration-200"
          >
            {loading ? 'Authenticating...' : 'Sign In to Dashboard'}
          </button>
        </form>

        {/* Quick Demo Role Switcher */}
        <div className="mt-8 pt-6 border-t border-slate-800">
          <p className="text-[11px] font-bold text-center text-slate-400 uppercase tracking-wider mb-3">
            Quick Role Switcher for Hackathon Demo
          </p>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setRoleDemo('admin@aquasense.ai', 'admin123')}
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-aqua-600/30 border border-slate-700 hover:border-aqua-500 text-center transition"
            >
              <ShieldCheck className="w-4 h-4 text-aqua-400 mx-auto mb-1" />
              <span className="block text-[11px] font-semibold text-slate-200">Admin</span>
            </button>
            <button
              onClick={() => setRoleDemo('facility@aquasense.ai', 'facility123')}
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-aqua-600/30 border border-slate-700 hover:border-aqua-500 text-center transition"
            >
              <UserCheck className="w-4 h-4 text-amber-400 mx-auto mb-1" />
              <span className="block text-[11px] font-semibold text-slate-200">Facility Mgr</span>
            </button>
            <button
              onClick={() => setRoleDemo('viewer@aquasense.ai', 'viewer123')}
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-aqua-600/30 border border-slate-700 hover:border-aqua-500 text-center transition"
            >
              <Eye className="w-4 h-4 text-blue-400 mx-auto mb-1" />
              <span className="block text-[11px] font-semibold text-slate-200">Viewer</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
