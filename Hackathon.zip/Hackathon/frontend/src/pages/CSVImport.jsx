import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useApp } from '../context/AppContext';
import { exportToCSV } from '../utils/csvExport';
import { formatDate } from '../utils/formatters';
import { 
  UploadCloud, FileSpreadsheet, CheckCircle2, AlertOctagon, Download, FileText, History, RefreshCw 
} from 'lucide-react';

const CSVImport = () => {
  const { showNotification, triggerRefresh } = useApp();
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [history, setHistory] = useState([]);

  const fetchHistory = async () => {
    try {
      const res = await API.get('/imports/history');
      setHistory(res.data || []);
    } catch (err) {
      console.error('Failed to load import history:', err);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (!selectedFile.name.endsWith('.csv')) {
        showNotification('Please select a valid CSV file', 'error');
        return;
      }
      setFile(selectedFile);
      setPreview(null);
    }
  };

  const handlePreview = async () => {
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await API.post('/imports/preview', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setPreview(res.data);
      showNotification(`CSV preview generated: ${res.data.acceptedCount} valid, ${res.data.rejectedCount} rejected`, 'info');
    } catch (err) {
      showNotification(err.response?.data?.message || 'Failed to validate CSV', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCommitImport = async () => {
    if (!file) return;
    setImporting(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await API.post('/imports/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      showNotification(`Import successful! ${res.data.importDoc?.acceptedRows} records added to MongoDB.`, 'success');
      setFile(null);
      setPreview(null);
      triggerRefresh();
      fetchHistory();
    } catch (err) {
      showNotification(err.response?.data?.message || 'Failed to import CSV into database', 'error');
    } finally {
      setImporting(false);
    }
  };

  const handleDownloadTemplate = () => {
    window.open('/api/imports/template', '_blank');
  };

  const handleDownloadErrorReport = () => {
    if (!preview || !preview.errors || preview.errors.length === 0) return;
    exportToCSV(`csv_validation_errors_${Date.now()}.csv`, preview.errors);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel p-6 rounded-2xl border border-aqua-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <UploadCloud className="w-6 h-6 text-aqua-400" />
            Water Consumption CSV Import Module
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Ingest bulk telemetry data with strict schema validation, duplicate detection, and rejected row logs.
          </p>
        </div>

        <button
          onClick={handleDownloadTemplate}
          className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-aqua-300 border border-aqua-500/30 text-xs font-semibold transition flex items-center gap-1.5"
        >
          <Download className="w-4 h-4 text-aqua-400" /> Download CSV Template
        </button>
      </div>

      {/* Uploader Box */}
      <div className="glass-panel p-8 rounded-2xl border border-slate-800 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-aqua-500/10 border border-aqua-500/30 flex items-center justify-center mx-auto text-aqua-400">
          <FileSpreadsheet className="w-8 h-8" />
        </div>

        <div>
          <h3 className="text-base font-bold text-white">Select Water Consumption CSV File</h3>
          <p className="text-xs text-slate-400 max-w-lg mx-auto mt-1">
            Required columns: <code className="text-aqua-300">timestamp</code>, <code className="text-aqua-300">building_id</code>, <code className="text-aqua-300">consumption_litres</code>. Optional: <code className="text-slate-300">occupancy</code>, <code className="text-slate-300">building_type</code>, <code className="text-slate-300">meter_id</code>.
          </p>
        </div>

        <div className="flex items-center justify-center space-x-3 max-w-md mx-auto">
          <input
            type="file"
            accept=".csv"
            onChange={handleFileChange}
            className="block w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-aqua-600 file:text-white hover:file:bg-aqua-500 cursor-pointer"
          />
        </div>

        {file && !preview && (
          <div className="pt-2">
            <button
              onClick={handlePreview}
              disabled={loading}
              className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-aqua-600 to-aqua-500 text-white font-semibold text-xs shadow-lg shadow-aqua-600/30 hover:opacity-90 transition"
            >
              {loading ? 'Validating CSV Rows...' : 'Run Pre-Import Validation'}
            </button>
          </div>
        )}
      </div>

      {/* Pre-Import Validation Preview Section */}
      {preview && (
        <div className="glass-panel p-6 rounded-2xl border border-aqua-500/30 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" /> Validation Summary for: {preview.fileName}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Total Rows Processed: <strong>{preview.totalRows}</strong>
              </p>
            </div>

            <div className="flex items-center space-x-3">
              {preview.rejectedCount > 0 && (
                <button
                  onClick={handleDownloadErrorReport}
                  className="px-3 py-1.5 rounded-lg bg-red-500/20 text-red-300 border border-red-500/30 text-xs font-semibold hover:bg-red-500/30 transition flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" /> Download Error CSV ({preview.rejectedCount})
                </button>
              )}
              <button
                onClick={handleCommitImport}
                disabled={importing || preview.acceptedCount === 0}
                className="px-5 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-aqua-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 hover:opacity-90 transition disabled:opacity-50"
              >
                {importing ? 'Importing to MongoDB...' : `Commit ${preview.acceptedCount} Valid Records to Database`}
              </button>
            </div>
          </div>

          {/* Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-300 uppercase">Accepted Rows (Valid)</p>
                <p className="text-2xl font-extrabold text-emerald-300">{preview.acceptedCount}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-emerald-400 opacity-80" />
            </div>

            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-300 uppercase">Rejected Rows (Invalid / Duplicate)</p>
                <p className="text-2xl font-extrabold text-red-400">{preview.rejectedCount}</p>
              </div>
              <AlertOctagon className="w-8 h-8 text-red-400 opacity-80" />
            </div>
          </div>

          {/* Error Details Log */}
          {preview.errors && preview.errors.length > 0 && (
            <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/20 max-h-48 overflow-y-auto space-y-1">
              <p className="text-xs font-bold text-red-300 mb-2">Validation Failure Rejection Log:</p>
              {preview.errors.map((err, idx) => (
                <p key={idx} className="text-xs text-red-400 font-mono">
                  Row {err.row}: {err.reason}
                </p>
              ))}
            </div>
          )}

          {/* Valid Preview Table */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Valid Records Preview (First 50 Rows)</h4>
            <div className="overflow-x-auto rounded-lg border border-slate-800">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-aqua-900/90 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Timestamp</th>
                    <th className="p-2.5">Building ID</th>
                    <th className="p-2.5">Type</th>
                    <th className="p-2.5 text-right">Consumption (L)</th>
                    <th className="p-2.5 text-right">Occupancy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {preview.previewRecords?.map((rec, i) => (
                    <tr key={i} className="hover:bg-slate-800/40">
                      <td className="p-2.5">{formatDate(rec.timestamp)}</td>
                      <td className="p-2.5 font-bold text-aqua-300">{rec.building_id}</td>
                      <td className="p-2.5">{rec.building_type}</td>
                      <td className="p-2.5 text-right font-bold text-white">{rec.consumption_litres} L</td>
                      <td className="p-2.5 text-right">{rec.occupancy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Import History Table */}
      <div className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <History className="w-5 h-5 text-aqua-400" />
          CSV Telemetry Import History
        </h3>

        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-aqua-900/90 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">Import Date</th>
                <th className="p-3">File Name</th>
                <th className="p-3">Imported By</th>
                <th className="p-3 text-right">Total Rows</th>
                <th className="p-3 text-right">Accepted</th>
                <th className="p-3 text-right">Rejected</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {history.map((h) => (
                <tr key={h._id} className="hover:bg-slate-800/40">
                  <td className="p-3">{formatDate(h.timestamp)}</td>
                  <td className="p-3 font-semibold text-white">{h.fileName}</td>
                  <td className="p-3">{h.importedBy}</td>
                  <td className="p-3 text-right font-mono">{h.totalRows}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">{h.acceptedRows}</td>
                  <td className="p-3 text-right font-bold text-red-400">{h.rejectedRows}</td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                      h.status === 'Success' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                      h.status === 'Partial' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                      'bg-red-500/20 text-red-300 border-red-500/30'
                    }`}>
                      {h.status}
                    </span>
                  </td>
                </tr>
              ))}

              {history.length === 0 && (
                <tr>
                  <td colSpan="7" className="p-6 text-center text-slate-400">
                    No import history records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CSVImport;
