import React, { createContext, useContext, useState, useEffect } from 'react';
import API from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem('aquasense_token');
      const savedUser = localStorage.getItem('aquasense_user');
      
      if (token && savedUser) {
        try {
          setUser(JSON.parse(savedUser));
        } catch (e) {
          localStorage.removeItem('aquasense_token');
          localStorage.removeItem('aquasense_user');
        }
      }
      setLoading(false);
    };

    checkAuth();
  }, []);

  const login = async (email, password) => {
    try {
      const res = await API.post('/auth/login', { email, password });
      const { token, ...userData } = res.data;
      localStorage.setItem('aquasense_token', token);
      localStorage.setItem('aquasense_user', JSON.stringify(userData));
      setUser(userData);
      return { success: true, user: userData };
    } catch (err) {
      return { 
        success: false, 
        message: err.response?.data?.message || 'Login failed. Please check credentials.' 
      };
    }
  };

  const logout = () => {
    localStorage.removeItem('aquasense_token');
    localStorage.removeItem('aquasense_user');
    setUser(null);
  };

  const isAdmin = user?.role === 'Administrator';
  const isFacilityManager = user?.role === 'Facility Manager' || user?.role === 'Administrator';

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAdmin, isFacilityManager }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
