import React, { createContext, useContext, useState, useEffect } from 'react';
import API from '../services/api';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [selectedBuilding, setSelectedBuilding] = useState('ALL');
  const [dateRange, setDateRange] = useState({ startDate: '', endDate: '' });
  const [buildings, setBuildings] = useState([]);
  const [notification, setNotification] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const triggerRefresh = () => setRefreshTrigger(prev => prev + 1);

  const showNotification = (message, type = 'info') => {
    setNotification({ message, type, id: Date.now() });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  useEffect(() => {
    const fetchBuildings = async () => {
      try {
        const res = await API.get('/buildings');
        setBuildings(res.data);
      } catch (err) {
        console.error('Failed to load buildings:', err);
      }
    };
    fetchBuildings();
  }, [refreshTrigger]);

  return (
    <AppContext.Provider value={{
      selectedBuilding,
      setSelectedBuilding,
      dateRange,
      setDateRange,
      buildings,
      notification,
      showNotification,
      triggerRefresh,
      refreshTrigger
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
