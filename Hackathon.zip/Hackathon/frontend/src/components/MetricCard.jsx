import React from 'react';

const MetricCard = ({ title, value, subtext, icon: Icon, color = 'teal', trend }) => {
  const colorMap = {
    teal: 'from-aqua-600/20 to-aqua-400/5 text-aqua-300 border-aqua-500/30',
    blue: 'from-blue-600/20 to-blue-400/5 text-blue-300 border-blue-500/30',
    amber: 'from-amber-600/20 to-amber-400/5 text-amber-300 border-amber-500/30',
    emerald: 'from-emerald-600/20 to-emerald-400/5 text-emerald-300 border-emerald-500/30',
    red: 'from-red-600/20 to-red-400/5 text-red-300 border-red-500/30',
    purple: 'from-purple-600/20 to-purple-400/5 text-purple-300 border-purple-500/30'
  };

  const iconBgMap = {
    teal: 'bg-aqua-500/20 text-aqua-400',
    blue: 'bg-blue-500/20 text-blue-400',
    amber: 'bg-amber-500/20 text-amber-400',
    emerald: 'bg-emerald-500/20 text-emerald-400',
    red: 'bg-red-500/20 text-red-400',
    purple: 'bg-purple-500/20 text-purple-400'
  };

  return (
    <div className={`p-4 rounded-xl glass-panel bg-gradient-to-br ${colorMap[color]} hover:scale-[1.01] transition duration-200`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">{title}</span>
        {Icon && (
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${iconBgMap[color]}`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>
      <div className="mt-2">
        <h3 className="text-2xl font-extrabold text-white tracking-tight">{value}</h3>
        {subtext && <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">{subtext}</p>}
      </div>
    </div>
  );
};

export default MetricCard;
