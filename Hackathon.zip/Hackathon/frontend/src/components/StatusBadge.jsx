import React from 'react';

export const AlertBadge = ({ severity }) => {
  const map = {
    Critical: 'bg-red-500/20 text-red-400 border-red-500/40 glow-red',
    High: 'bg-amber-500/20 text-amber-400 border-amber-500/40',
    Medium: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
    Low: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    None: 'bg-slate-500/20 text-slate-400 border-slate-500/30'
  };

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${map[severity] || map.Low}`}>
      {severity} Severity
    </span>
  );
};

export const StatusBadge = ({ status }) => {
  const map = {
    Open: 'bg-red-500/20 text-red-300 border-red-500/30',
    Assigned: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    'In Progress': 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    Resolved: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 glow-teal',
    Closed: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
    Success: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    Partial: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    Failed: 'bg-red-500/20 text-red-300 border-red-500/30'
  };

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${map[status] || map.Open}`}>
      {status}
    </span>
  );
};
