import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Droplets, Building2, LogOut, User as UserIcon, Bell, Calendar } from 'lucide-react';

const Navbar = ({ activePage, setActivePage }) => {
  const { user, logout } = useAuth();
  const { selectedBuilding, setSelectedBuilding, buildings, notification } = useApp();

  return (
    <header className="h-16 border-b border-slate-800 bg-aqua-900/90 backdrop-blur-md sticky top-0 z-30 px-4 flex items-center justify-between">
      {/* Left: Brand */}
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-aqua-600 to-aqua-400 flex items-center justify-center shadow-lg shadow-aqua-600/30">
          <Droplets className="w-6 h-6 text-white animate-pulse" />
        </div>
        <div>
          <h1 className="font-extrabold text-xl tracking-tight text-white flex items-center gap-2">
            AquaSense <span className="text-xs px-2 py-0.5 rounded-full bg-aqua-500/20 text-aqua-400 border border-aqua-500/30">AI v1.0</span>
          </h1>
          <p className="text-xs text-slate-400 font-medium">Explainable Water Intelligence Platform</p>
        </div>
      </div>

      {/* Center: Global Building Filter */}
      <div className="hidden md:flex items-center space-x-2 bg-aqua-950/70 border border-slate-800 rounded-lg p-1.5">
        <Building2 className="w-4 h-4 text-aqua-400 ml-2" />
        <span className="text-xs font-semibold text-slate-400">Filter Building:</span>
        <select
          value={selectedBuilding}
          onChange={(e) => setSelectedBuilding(e.target.value)}
          className="bg-transparent text-sm text-slate-200 focus:outline-none cursor-pointer pr-2 font-medium"
        >
          <option value="ALL" className="bg-aqua-900 text-white">All Buildings (Organization-wide)</option>
          {buildings.map(b => (
            <option key={b.building_id} value={b.building_id} className="bg-aqua-900 text-white">
              {b.building_id} - {b.name} ({b.building_type})
            </option>
          ))}
        </select>
      </div>

      {/* Right: User Profile & Actions */}
      <div className="flex items-center space-x-4">
        {notification && (
          <div className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center space-x-1 animate-bounce ${
            notification.type === 'error' ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-aqua-500/20 text-aqua-300 border border-aqua-500/30'
          }`}>
            <Bell className="w-3.5 h-3.5" />
            <span>{notification.message}</span>
          </div>
        )}

        <div className="flex items-center space-x-3 border-l border-slate-800 pl-4">
          <button
            onClick={() => setActivePage('profile')}
            className="flex items-center space-x-2 hover:bg-slate-800/60 p-1.5 rounded-lg transition"
          >
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-aqua-500/40 flex items-center justify-center text-aqua-300 font-bold text-sm">
              {user?.name ? user.name.charAt(0) : 'U'}
            </div>
            <div className="hidden lg:block text-left">
              <p className="text-xs font-semibold text-slate-200 leading-tight">{user?.name || 'User'}</p>
              <span className="text-[10px] text-aqua-400 font-medium px-1.5 py-0.2 rounded bg-aqua-500/10 inline-block">
                {user?.role || 'Viewer'}
              </span>
            </div>
          </button>

          <button
            onClick={logout}
            title="Log Out"
            className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
