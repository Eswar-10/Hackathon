import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  LayoutDashboard, 
  Database, 
  UploadCloud, 
  AlertTriangle, 
  TrendingUp, 
  GitCompare, 
  CheckSquare, 
  Sparkles, 
  FileText, 
  Building, 
  Users, 
  Settings, 
  UserCircle 
} from 'lucide-react';

const Sidebar = ({ activePage, setActivePage }) => {
  const { isAdmin, isFacilityManager } = useAuth();

  const navItems = [
    { id: 'dashboard', label: 'Main Dashboard', icon: LayoutDashboard },
    { id: 'water-data', label: 'Water Data', icon: Database },
    { id: 'csv-import', label: 'CSV Import', icon: UploadCloud },
    { id: 'anomaly-detection', label: 'Anomaly Detection', icon: AlertTriangle, badge: 'Explainable' },
    { id: 'forecasting', label: 'AI Forecasting', icon: TrendingUp, badge: '7-Day ML' },
    { id: 'building-comparison', label: 'Fair Building Comparison', icon: GitCompare },
    { id: 'task-management', label: 'Task Workflow & Verification', icon: CheckSquare, highlight: true },
    { id: 'recommendations', label: 'Recommendations', icon: Sparkles },
    { id: 'reports', label: 'Reports & Analytics', icon: FileText },
  ];

  const adminItems = [
    { id: 'building-management', label: 'Building Management', icon: Building, role: 'Facility' },
    { id: 'user-management', label: 'User Management', icon: Users, role: 'Admin' },
    { id: 'settings', label: 'Organization Settings', icon: Settings },
    { id: 'profile', label: 'My Profile', icon: UserCircle },
  ];

  return (
    <aside className="w-64 bg-aqua-900/60 border-r border-slate-800 flex flex-col justify-between shrink-0 hidden md:flex">
      <div className="p-4 space-y-6">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-2">Main Navigation</p>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActivePage(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition ${
                    isActive 
                      ? 'bg-gradient-to-r from-aqua-600 to-aqua-500 text-white font-semibold shadow-md shadow-aqua-600/20' 
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  } ${item.highlight ? 'border border-aqua-500/40 bg-aqua-500/10' : ''}`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : (item.highlight ? 'text-aqua-400' : 'text-slate-400')}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-aqua-400/20 text-aqua-300 border border-aqua-400/30">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-2">Management & Admin</p>
          <nav className="space-y-1">
            {adminItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              
              if (item.role === 'Admin' && !isAdmin) return null;
              if (item.role === 'Facility' && !isFacilityManager) return null;

              return (
                <button
                  key={item.id}
                  onClick={() => setActivePage(item.id)}
                  className={`w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-xs font-medium transition ${
                    isActive 
                      ? 'bg-aqua-600 text-white font-semibold' 
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      <div className="p-4 border-t border-slate-800/80 bg-aqua-950/40">
        <div className="glass-card p-3 rounded-xl border border-aqua-500/20">
          <p className="text-xs font-bold text-aqua-300 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            System Operational
          </p>
          <p className="text-[11px] text-slate-400 mt-1">MongoDB & Analytics Sync Active</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
