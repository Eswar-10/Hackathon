/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        aqua: {
          950: '#070F1E',
          900: '#0B192C',
          850: '#112239',
          800: '#1E3E62',
          700: '#2A528A',
          600: '#008080', // Deep Teal
          500: '#00A896', // Vibrant Teal
          400: '#02C39A', // Electric Emerald
          300: '#00D26A', // Bright Accent
          100: '#E6F4F1',
          50: '#F0F9F8'
        }
      },
      fontFamily: {
        sans: ['Inter', 'Outfit', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
