import io
import unittest
from datetime import datetime, timedelta, timezone

from services.anomaly import detect_water_anomalies, summarize_reading_quality
from services.validation import validate_csv_content


class HybridDetectionTests(unittest.TestCase):
    def make_readings(self, count=48):
        start = datetime(2026, 10, 1, tzinfo=timezone.utc)
        readings = []
        for i in range(count):
            ts = start + timedelta(hours=i)
            hour = ts.hour
            base = 300 if 7 <= hour <= 9 else (100 if hour <= 5 or hour >= 23 else 180)
            readings.append({
                "timestamp": ts.isoformat(), "building_id": "BLDG-TEST",
                "meter_id": "MTR-TEST", "consumption_litres": base,
                "occupancy": 100, "building_type": "Test"
            })
        return readings

    def test_invalid_rows_are_ignored(self):
        readings = self.make_readings()
        readings.extend([
            {"timestamp": "not-a-date", "building_id": "BLDG-TEST", "consumption_litres": 9999},
            {"timestamp": "2026-10-03T01:00:00Z", "building_id": "BLDG-TEST", "consumption_litres": -1},
        ])
        alerts = detect_water_anomalies(readings)
        self.assertTrue(all(a["data_quality_status"] == "valid" for a in alerts))

    def test_spike_is_flagged_with_explanation(self):
        readings = self.make_readings()
        ts = datetime.fromisoformat(readings[-1]["timestamp"].replace("Z", "+00:00")) + timedelta(hours=1)
        readings.append({
            "timestamp": ts.isoformat(), "building_id": "BLDG-TEST",
            "meter_id": "MTR-TEST", "consumption_litres": 1500,
            "occupancy": 100, "building_type": "Test"
        })
        alerts = detect_water_anomalies(readings, 30)
        self.assertTrue(alerts)
        self.assertTrue(any(a["rule_flags"] for a in alerts))
        self.assertIn("recommended_action", alerts[-1])

    def test_quality_summary_only_checks_staleness_for_live_sources(self):
        readings = self.make_readings(4)
        readings[0]["source"] = "Simulated"
        quality = summarize_reading_quality(readings)
        self.assertFalse(quality["live_feed_connected"])
        self.assertEqual(quality["stale_live_meters"], [])

        for reading in readings:
            reading["source"] = "Live_Meter"
        quality_live = summarize_reading_quality(readings, stale_after_minutes=180)
        self.assertTrue(quality_live["live_feed_connected"])
        self.assertTrue(quality_live["stale_live_meters"])

    def test_csv_rejects_negative_and_duplicate_readings(self):
        csv = (
            "timestamp,building_id,meter_id,consumption_litres,occupancy\n"
            "2026-10-01T08:00:00Z,B1,M1,120,20\n"
            "2026-10-01T08:00:00Z,B1,M1,130,20\n"
            "2026-10-01T09:00:00Z,B1,M1,-1,20\n"
        ).encode()
        result = validate_csv_content(csv)
        self.assertEqual(result["accepted_count"], 1)
        self.assertEqual(result["rejected_count"], 2)


if __name__ == "__main__":
    unittest.main()
