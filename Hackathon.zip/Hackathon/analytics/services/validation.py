"""CSV validation for AquaSense AI water readings."""
import io
import math
from typing import Any, Dict

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ["timestamp", "building_id", "consumption_litres"]


def validate_csv_content(csv_bytes: bytes) -> Dict[str, Any]:
    try:
        df = pd.read_csv(io.BytesIO(csv_bytes))
    except Exception as exc:
        return {
            "valid": False, "error": f"Failed to parse CSV file: {exc}",
            "total_rows": 0, "accepted_count": 0, "rejected_count": 0,
            "errors": [{"row": 0, "reason": "CSV parse error"}],
            "warnings": [], "preview_records": [],
        }

    # Normalize headers once so casing/extra spaces do not silently break validation.
    df.columns = [str(col).strip().lower() for col in df.columns]
    missing_cols = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing_cols:
        return {
            "valid": False, "error": f"Missing required columns: {', '.join(missing_cols)}",
            "total_rows": len(df), "accepted_count": 0, "rejected_count": len(df),
            "errors": [{"row": 1, "reason": f"Missing columns: {', '.join(missing_cols)}"}],
            "warnings": [], "preview_records": [],
        }

    df["_row"] = np.arange(2, len(df) + 2)
    df["_timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    df["_consumption"] = pd.to_numeric(df["consumption_litres"], errors="coerce")
    df["_building"] = df["building_id"].fillna("").astype(str).str.strip()
    if "meter_id" in df.columns:
        df["_meter"] = df["meter_id"].fillna("UNKNOWN-METER").astype(str).str.strip()
    else:
        df["_meter"] = "UNKNOWN-METER"

    errors = []
    rejected = set()
    warnings = []
    for _, row in df.iterrows():
        row_no = int(row["_row"])
        if pd.isna(row["_timestamp"]):
            rejected.add(row_no)
            errors.append({"row": row_no, "reason": "Missing or invalid timestamp"})
        if not row["_building"]:
            rejected.add(row_no)
            errors.append({"row": row_no, "reason": "Missing building_id"})
        value = row["_consumption"]
        if pd.isna(value) or not math.isfinite(float(value)) or float(value) < 0:
            rejected.add(row_no)
            errors.append({"row": row_no, "reason": "Consumption must be a finite, non-negative number"})
        if "occupancy" in df.columns and pd.notna(row.get("occupancy")):
            occ = pd.to_numeric(pd.Series([row.get("occupancy")]), errors="coerce").iloc[0]
            if pd.isna(occ) or not math.isfinite(float(occ)) or float(occ) < 0:
                rejected.add(row_no)
                errors.append({"row": row_no, "reason": "Occupancy must be a non-negative number when provided"})

    candidates = df.loc[~df["_row"].isin(rejected) & df["_timestamp"].notna()].copy()
    dup_mask = candidates.duplicated(subset=["_building", "_meter", "_timestamp"], keep="first")
    for _, row in candidates.loc[dup_mask].iterrows():
        row_no = int(row["_row"])
        rejected.add(row_no)
        errors.append({"row": row_no, "reason": "Duplicate reading for the same building, meter, and timestamp"})

    # Out-of-order timestamps are surfaced as a warning, not rejected; valid historical
    # imports may be unordered and the analytics engine sorts by time before processing.
    ordered = candidates.loc[~candidates["_row"].isin(rejected)]
    for (building, meter), group in ordered.groupby(["_building", "_meter"], dropna=False):
        times = group["_timestamp"].tolist()
        if any(times[i] < times[i - 1] for i in range(1, len(times))):
            warnings.append({"building_id": str(building), "meter_id": str(meter), "reason": "Readings are not chronological; they will be sorted before analysis"})

    accepted = df.loc[~df["_row"].isin(rejected)]
    preview = []
    for _, row in accepted.head(100).iterrows():
        rec = {
            "timestamp": row["_timestamp"].isoformat(),
            "building_id": str(row["_building"]),
            "consumption_litres": float(row["_consumption"]),
            "building_type": str(row.get("building_type", "General")) if pd.notna(row.get("building_type", "General")) else "General",
            "meter_id": str(row["_meter"] or "UNKNOWN-METER"),
        }
        if "occupancy" in df.columns and pd.notna(row.get("occupancy")):
            rec["occupancy"] = float(row["occupancy"])
        preview.append(rec)

    return {
        "valid": len(rejected) < len(df),
        "total_rows": len(df),
        "accepted_count": int(len(df) - len(rejected)),
        "rejected_count": int(len(rejected)),
        "errors": errors,
        "warnings": warnings,
        "preview_records": preview,
    }
