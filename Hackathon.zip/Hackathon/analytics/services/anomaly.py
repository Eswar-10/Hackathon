"""Hybrid water-consumption anomaly detection.

This service identifies unusual readings for investigation; it does not prove a leak.
The input currently represents interval consumption (litres per interval), not a
cumulative meter register. Cumulative-register reset/rollover handling belongs in
an adapter before these readings reach this function.
"""
from __future__ import annotations

from typing import Any, Dict, List
import math

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest


def _number(value: Any) -> float | None:
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None



def summarize_reading_quality(readings: List[Dict[str, Any]], stale_after_minutes: int = 180) -> Dict[str, Any]:
    """Summarize data quality separately from anomaly/leak alerts.

    Staleness is evaluated only for explicitly live meter sources; imported historical
    and simulated datasets are not incorrectly called stale based on wall-clock time.
    """
    total = len(readings or [])
    if total == 0:
        return {"total_rows": 0, "valid_rows": 0, "invalid_rows": 0, "duplicate_rows": 0,
                "out_of_order_groups": 0, "missing_interval_gaps": 0, "stale_live_meters": [],
                "source_counts": {}, "live_feed_connected": False}

    df = pd.DataFrame(readings)
    source_counts = df.get("source", pd.Series(["Unknown"] * len(df))).fillna("Unknown").astype(str).value_counts().to_dict()
    df["ts"] = pd.to_datetime(df.get("timestamp"), errors="coerce", utc=True)
    df["building_id"] = df.get("building_id", pd.Series([""] * len(df))).fillna("").astype(str).str.strip()
    df["meter_id"] = df.get("meter_id", pd.Series(["UNKNOWN-METER"] * len(df))).fillna("UNKNOWN-METER").astype(str)
    values = pd.to_numeric(df.get("consumption_litres", pd.Series([None] * len(df))), errors="coerce")
    valid_mask = df["ts"].notna() & df["building_id"].ne("") & values.notna() & np.isfinite(values) & values.ge(0)
    valid = df.loc[valid_mask].copy()
    valid["consumption"] = values.loc[valid_mask]
    duplicate_mask = valid.duplicated(["building_id", "meter_id", "ts"], keep="first")
    duplicate_count = int(duplicate_mask.sum())
    valid = valid.loc[~duplicate_mask].copy()

    out_of_order_groups = 0
    missing_gaps = 0
    for _, group in valid.groupby(["building_id", "meter_id"]):
        # Detect out-of-order data using the original order, then analyze sorted times.
        original_times = group.sort_index()["ts"].tolist()
        if any(original_times[i] < original_times[i - 1] for i in range(1, len(original_times))):
            out_of_order_groups += 1
        times = group["ts"].sort_values().drop_duplicates()
        deltas = times.diff().dropna().dt.total_seconds()
        positive = deltas[deltas > 0]
        if len(positive) >= 3:
            cadence = float(positive.median())
            missing_gaps += int((positive > cadence * 3).sum())

    live_sources = {"Meter_API", "Meter_Gateway", "Live_Meter"}
    live = valid.loc[valid.get("source", pd.Series(["Unknown"] * len(valid), index=valid.index)).isin(live_sources)]
    now = pd.Timestamp.now(tz="UTC")
    stale_meters = []
    if not live.empty:
        for (building_id, meter_id), group in live.groupby(["building_id", "meter_id"]):
            latest = group["ts"].max()
            age_minutes = (now - latest).total_seconds() / 60
            if age_minutes > max(1, int(stale_after_minutes)):
                stale_meters.append({"building_id": str(building_id), "meter_id": str(meter_id),
                                     "latest_timestamp": latest.isoformat(), "age_minutes": round(age_minutes, 1)})

    return {
        "total_rows": total,
        "valid_rows": int(valid_mask.sum()),
        "invalid_rows": int(total - valid_mask.sum()),
        "duplicate_rows": duplicate_count,
        "out_of_order_groups": out_of_order_groups,
        "missing_interval_gaps": missing_gaps,
        "stale_live_meters": stale_meters,
        "source_counts": source_counts,
        "live_feed_connected": not live.empty,
        "stale_after_minutes": max(1, int(stale_after_minutes)),
    }

def detect_water_anomalies(
    readings: List[Dict[str, Any]],
    threshold_pct: float = 30.0,
) -> List[Dict[str, Any]]:
    """Validate, apply safeguards/rules, then use ML as supporting evidence.

    Backward-compatible alert fields are retained for the existing Node API/UI.
    Invalid rows are skipped rather than being interpreted as zero consumption.
    """
    if not readings:
        return []

    try:
        threshold_pct = float(threshold_pct)
    except (TypeError, ValueError):
        threshold_pct = 30.0
    if not math.isfinite(threshold_pct) or threshold_pct <= 0:
        threshold_pct = 30.0

    df = pd.DataFrame(readings)
    required = {"timestamp", "building_id", "consumption_litres"}
    if not required.issubset(df.columns):
        return []

    df["_input_order"] = np.arange(len(df))
    df["ts"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    df["consumption"] = pd.to_numeric(df["consumption_litres"], errors="coerce")
    df["building_id"] = df["building_id"].fillna("").astype(str).str.strip()
    df["meter_id"] = df["meter_id"].fillna("UNKNOWN-METER").astype(str) if "meter_id" in df.columns else "UNKNOWN-METER"

    # Reject malformed rows and duplicates per physical meter/time. Missing is not zero.
    valid = (
        df["ts"].notna()
        & df["building_id"].ne("")
        & df["consumption"].notna()
        & np.isfinite(df["consumption"])
        & df["consumption"].ge(0)
    )
    df = df.loc[valid].copy()
    if df.empty:
        return []
    df = df.sort_values(["building_id", "meter_id", "ts", "_input_order"])
    df = df.drop_duplicates(["building_id", "meter_id", "ts"], keep="first")
    df = df.reset_index(drop=True)

    df["hour"] = df["ts"].dt.hour
    df["dayofweek"] = df["ts"].dt.dayofweek
    if "occupancy" in df.columns:
        df["occupancy"] = pd.to_numeric(df["occupancy"], errors="coerce").where(lambda s: s >= 0, np.nan)
    else:
        df["occupancy"] = np.nan

    # Baselines exclude the current observation to reduce self-contamination.
    df["prior_rolling_median"] = df.groupby(["building_id", "meter_id"])["consumption"].transform(
        lambda s: s.shift(1).rolling(window=24, min_periods=3).median()
    )
    df["same_hour_prior_median"] = df.groupby(["building_id", "meter_id", "hour"])["consumption"].transform(
        lambda s: s.shift(1).rolling(window=8, min_periods=2).median()
    )
    df["same_hour_history_count"] = df.groupby(["building_id", "meter_id", "hour"])["consumption"].transform(
        lambda s: s.shift(1).rolling(window=8, min_periods=1).count()
    ).fillna(0)
    df["expected_consumption"] = df["same_hour_prior_median"].combine_first(df["prior_rolling_median"])

    # ML is only trained per meter when sufficient history exists. It is evidence,
    # not a standalone leak decision. Small datasets fall back to deterministic rules.
    df["ml_flag"] = False
    df["ml_available"] = False
    for _, indices in df.groupby(["building_id", "meter_id"]).groups.items():
        idx = list(indices)
        if len(idx) < 30:
            continue
        group = df.loc[idx]
        features = pd.DataFrame({
            "consumption": group["consumption"],
            "hour": group["hour"],
            "dayofweek": group["dayofweek"],
            "occupancy": group["occupancy"].fillna(group["occupancy"].median() if group["occupancy"].notna().any() else 0),
        }).replace([np.inf, -np.inf], np.nan).fillna(0)
        try:
            model = IsolationForest(contamination=0.05, random_state=42, n_estimators=100)
            predictions = model.fit_predict(features)
            df.loc[idx, "ml_flag"] = predictions == -1
            df.loc[idx, "ml_available"] = True
        except (ValueError, FloatingPointError):
            pass

    anomalies: List[Dict[str, Any]] = []
    for _, row in df.iterrows():
        observed = float(row["consumption"])
        expected_value = row["expected_consumption"]
        if pd.isna(expected_value) or not math.isfinite(float(expected_value)):
            # Not enough prior context: don't manufacture a baseline or score.
            continue
        expected = max(0.0, float(expected_value))
        deviation = observed - expected
        dev_pct = (deviation / max(expected, 1.0)) * 100.0
        hour = int(row["hour"])
        overnight = hour >= 23 or hour <= 5
        ml_flag = bool(row["ml_flag"])

        # Explicit hard safeguards can be supplied by the building adapter.
        hard_limit = _number(row.get("max_flow_litres"))
        night_limit = _number(row.get("max_night_flow_litres"))
        hard_limit_breach = hard_limit is not None and hard_limit > 0 and observed > hard_limit
        night_limit_breach = overnight and night_limit is not None and night_limit > 0 and observed > night_limit
        has_same_hour_baseline = float(row["same_hour_history_count"]) >= 2
        deviation_rule = has_same_hour_baseline and dev_pct >= threshold_pct and deviation >= 50.0
        overnight_rule = has_same_hour_baseline and overnight and dev_pct >= max(20.0, threshold_pct * 0.75) and deviation >= 30.0
        strong_deviation_rule = has_same_hour_baseline and dev_pct >= max(100.0, threshold_pct * 2) and deviation >= 100.0
        persistent_rule = False
        # Persistent elevated flow: three consecutive readings above the same baseline.
        previous = df.loc[(df.index < row.name) & (df["building_id"] == row["building_id"]) & (df["meter_id"] == row["meter_id"])].tail(2)
        if len(previous) == 2:
            prior_vals = previous["consumption"].astype(float).tolist()
            persistent_rule = all(v > expected * 1.25 for v in prior_vals) and observed > expected * 1.25

        rule_flags = []
        if hard_limit_breach:
            rule_flags.append("Configured maximum-flow safeguard breached")
        if night_limit_breach:
            rule_flags.append("Configured overnight-flow safeguard breached")
        if deviation_rule:
            rule_flags.append("Consumption exceeds the configured percentage and absolute-deviation thresholds")
        if overnight_rule:
            rule_flags.append("Elevated overnight consumption compared with prior baseline")
        if persistent_rule:
            rule_flags.append("Elevated consumption persisted across three consecutive readings")

        # ML alone cannot declare a leak. It can support an already meaningful deviation.
        ml_support = ml_flag and dev_pct >= max(15.0, threshold_pct * 0.5) and deviation >= 30.0
        ml_available = bool(row["ml_available"])
        # With enough history, ML supports ordinary deviation alerts. Hard configured
        # limits, persistent elevated flow, and extreme deviations remain independent
        # safeguards. If there is too little data for ML, deterministic rules take over.
        if ml_available:
            is_anomaly = bool(
                hard_limit_breach or night_limit_breach or persistent_rule or strong_deviation_rule
                or (deviation_rule and ml_support)
                or (overnight_rule and (ml_support or persistent_rule))
            )
        else:
            is_anomaly = bool(rule_flags)
        if not is_anomaly:
            continue

        if hard_limit_breach or night_limit_breach or dev_pct >= 100 or deviation >= max(expected * 2, 250):
            severity = "Critical"
        elif dev_pct >= 60 or persistent_rule:
            severity = "High"
        elif dev_pct >= threshold_pct or overnight_rule:
            severity = "Medium"
        else:
            severity = "Low"

        factors = list(rule_flags)
        if ml_support:
            factors.append("Isolation Forest identified an unusual pattern and supports the rule-based evidence")
        if not factors and ml_flag:
            factors.append("ML flagged an unusual pattern; treated as supporting evidence only")
        factors.append(f"Observed {observed:.1f} L vs prior baseline {expected:.1f} L ({dev_pct:+.1f}%)")
        if overnight:
            factors.append("Reading occurred during the configured overnight window; investigate before diagnosing a leak")

        if hard_limit_breach or night_limit_breach or severity in ("High", "Critical"):
            action = "Verify the meter reading, inspect the relevant shutoff valves and plumbing, and compare nearby sub-meters before taking corrective action."
        elif overnight:
            action = "Check whether the overnight flow is expected, then inspect toilets, valves, and visible pipework if it persists."
        else:
            action = "Review occupancy and scheduled water use, then compare this meter with recent readings before dispatching maintenance."

        anomalies.append({
            "timestamp": row["ts"].isoformat(),
            "building_id": str(row["building_id"]),
            "building_type": str(row.get("building_type", "General")),
            "meter_id": str(row["meter_id"]),
            "observed_consumption": round(observed, 2),
            "expected_consumption": round(expected, 2),
            "absolute_deviation": round(deviation, 2),
            "percentage_deviation": round(dev_pct, 2),
            "z_score": None,
            "severity": severity,
            "anomaly_type": "Possible leakage" if (overnight_rule or persistent_rule or night_limit_breach) else "Unusual consumption",
            "contributing_factors": factors,
            "recommended_action": action,
            "isolation_forest_flagged": ml_flag,
            "ml_available": ml_available,
            "detection_method": "hybrid" if ml_support else "rules",
            "rule_flags": rule_flags,
            "data_quality_status": "valid",
            "confidence_score": None,
        })

    return anomalies
