from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import uvicorn

from services.validation import validate_csv_content
from services.anomaly import detect_water_anomalies, summarize_reading_quality
from services.forecast import forecast_water_demand

app = FastAPI(title="AquaSense AI Analytics Engine", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnomalyRequest(BaseModel):
    readings: List[Dict[str, Any]]
    threshold_pct: Optional[float] = 30.0
    stale_after_minutes: Optional[int] = 180

class ForecastRequest(BaseModel):
    readings: List[Dict[str, Any]]
    days_ahead: Optional[int] = 7

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "AquaSense AI Python Analytics Engine",
        "version": "1.0.0"
    }

@app.post("/validate-csv")
async def validate_csv(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    content = await file.read()
    result = validate_csv_content(content)
    return result

@app.post("/detect-anomalies")
def detect_anomalies(req: AnomalyRequest):
    anomalies = detect_water_anomalies(req.readings, req.threshold_pct or 30.0)
    quality = summarize_reading_quality(req.readings, req.stale_after_minutes or 180)
    return {
        "status": "success",
        "total_anomalies": len(anomalies),
        "anomalies": anomalies,
        "data_quality": quality,
    }

@app.post("/forecast")
def generate_forecast(req: ForecastRequest):
    forecast_res = forecast_water_demand(req.readings, req.days_ahead or 7)
    return forecast_res

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
