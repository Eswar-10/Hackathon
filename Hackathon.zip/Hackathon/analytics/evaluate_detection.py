"""Reproducible evaluation on synthetic data only (not field-performance evidence).

Run from analytics/: python evaluate_detection.py
Outputs precision, recall, F1, false-positive rate, and first-anomaly detection delay.
"""
from datetime import datetime, timedelta, timezone
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

from services.anomaly import detect_water_anomalies


def build_synthetic_dataset():
    rng = np.random.default_rng(42)
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    rows = []
    for i in range(24 * 21):
        ts = start + timedelta(hours=i)
        hour = ts.hour
        base = 320 if 7 <= hour <= 9 else 240 if 12 <= hour <= 14 else 280 if 18 <= hour <= 20 else 90 if hour <= 5 or hour >= 23 else 170
        value = max(0, base + rng.normal(0, 12))
        is_anomaly = False
        # A five-hour overnight event plus two isolated spikes; labels are known because
        # this dataset is synthetic and the anomaly injection is controlled by this script.
        if 24 * 8 + 1 <= i <= 24 * 8 + 5:
            value = 720 + rng.normal(0, 15)
            is_anomaly = True
        elif i in (24 * 12 + 10, 24 * 17 + 15):
            value = 800 + rng.normal(0, 20)
            is_anomaly = True
        rows.append({
            "timestamp": ts.isoformat(), "building_id": "SYNTHETIC-B1",
            "meter_id": "SYNTHETIC-M1", "consumption_litres": round(float(value), 2),
            "occupancy": 100, "building_type": "Synthetic", "ground_truth_anomaly": is_anomaly,
        })
    return rows


def metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=bool)
    y_pred = np.asarray(y_pred, dtype=bool)
    tp = int(np.sum(y_true & y_pred))
    fp = int(np.sum(~y_true & y_pred))
    fn = int(np.sum(y_true & ~y_pred))
    tn = int(np.sum(~y_true & ~y_pred))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    fpr = fp / (fp + tn) if fp + tn else 0.0
    delay = None
    actual_indices = np.flatnonzero(y_true)
    if len(actual_indices):
        first = int(actual_indices[0])
        hits = np.flatnonzero(y_true & y_pred)
        if len(hits):
            delay = int(hits[0] - first)
    return {
        "precision": round(precision, 4), "recall": round(recall, 4),
        "f1": round(f1, 4), "false_positive_rate": round(fpr, 4),
        "first_event_detection_delay_hours": delay,
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
    }


def main():
    rows = build_synthetic_dataset()
    truth = [r["ground_truth_anomaly"] for r in rows]
    model_rows = [{k: v for k, v in row.items() if k != "ground_truth_anomaly"} for row in rows]

    # Rules-only baseline for comparison: configured percentage + absolute difference
    # against a rolling median made only from prior readings.
    frame = pd.DataFrame(model_rows)
    frame["ts"] = pd.to_datetime(frame["timestamp"], utc=True)
    frame["hour"] = frame["ts"].dt.hour
    frame["same_hour_prior_median"] = frame.groupby("hour")["consumption_litres"].transform(
        lambda values: values.shift(1).rolling(8, min_periods=2).median()
    )
    frame["same_hour_count"] = frame.groupby("hour")["consumption_litres"].transform(
        lambda values: values.shift(1).rolling(8, min_periods=1).count()
    )
    frame["deviation"] = frame["consumption_litres"] - frame["same_hour_prior_median"]
    frame["deviation_pct"] = frame["deviation"] / frame["same_hour_prior_median"].clip(lower=1) * 100
    has_baseline = frame["same_hour_count"] >= 2
    rules_pred = has_baseline & (((frame["deviation_pct"] >= 30) & (frame["deviation"] >= 50)) | (
        frame["hour"].isin([23, 0, 1, 2, 3, 4, 5]) &
        (frame["deviation_pct"] >= 22.5) & (frame["deviation"] >= 30)
    ))
    rules_pred = rules_pred.fillna(False).to_numpy()

    # ML-only comparison uses the same feature family and a deterministic model.
    features = pd.DataFrame({
        "consumption": frame["consumption_litres"], "hour": frame["hour"],
        "dayofweek": frame["ts"].dt.dayofweek, "occupancy": frame["occupancy"],
    })
    ml_pred = IsolationForest(contamination=0.05, random_state=42, n_estimators=100).fit_predict(features) == -1

    # Hybrid prediction uses the production detector's validated rules + ML support.
    hybrid_alerts = detect_water_anomalies(model_rows, threshold_pct=30)
    hybrid_timestamps = {a["timestamp"] for a in hybrid_alerts}
    hybrid_pred = np.array([r["timestamp"] in hybrid_timestamps for r in model_rows], dtype=bool)

    result = {
        "dataset": "synthetic only; 504 hourly records with 7 injected anomaly records",
        "note": "These are reproducible prototype metrics, not real-world validation or guaranteed leak-detection performance.",
        "rules_only": metrics(truth, rules_pred),
        "ml_only": metrics(truth, ml_pred),
        "hybrid": metrics(truth, hybrid_pred),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
