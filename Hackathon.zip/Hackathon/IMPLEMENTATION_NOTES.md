# AquaSense AI — Incremental Hybrid Anomaly Detection Update

This update modifies the existing prototype; it does not replace the application.

## What changed

- Python anomaly detection now validates reading fields, skips malformed/duplicate rows, sorts by meter/time, uses prior-only baselines, and uses Isolation Forest only when enough history exists.
- Hybrid decisions use configured overnight-flow limits, historical deviations, persistent elevated flow, and ML as supporting evidence. Alerts describe unusual consumption / possible leakage for investigation; they do not prove a leak.
- Python CSV validation now reports accepted/rejected rows and warnings for unordered readings and large gaps inferred from the data cadence.
- The anomaly API returns a separate reading-quality summary (invalid/duplicate counts, time-order/gap warnings, source counts). Stale checks run only for explicitly live sources (`Meter_API`, `Meter_Gateway`, `Live_Meter`), not simulated or historical imports.
- Node CSV preview/import now checks required identity/time/consumption fields, finite non-negative values, optional occupancy, and duplicates per building + meter + timestamp. The line parser supports quoted commas but not quoted fields spanning multiple lines.
- Node fallback is explicitly rules-only and uses a prior-reading baseline rather than the whole-series average.
- Alert documents now retain detection method, rule flags, ML availability, and data-quality status. The UI no longer invents a default 85% confidence score.
- Seed readings are labelled `Simulated` rather than `CSV_Import`.
- Added focused Python regression tests and a synthetic evaluation script (4 tests currently pass).

## Run

### Python analytics (Windows PowerShell)

```powershell
cd .\analytics
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python evaluate_detection.py
python -m uvicorn app:app --reload --host 127.0.0.1 --port 8000
```

### Backend

Copy `.env.example` to `.env`, edit `MONGODB_URI` and `JWT_SECRET`, then:

```powershell
cd .\backend
npm install
npm run dev
```

### Frontend

```powershell
cd .\frontend
npm install
npm run dev
```

## Important limits

- The current reading schema stores interval consumption in litres. Cumulative meter-register reset/rollover handling is not implemented because the current input model does not carry a cumulative register value.
- Actual live meter integration depends on a compatible meter interface / gateway / API. Seed readings are simulated.
- `evaluate_detection.py` uses synthetic injected events. Its output is not real-world accuracy evidence; evaluate with chronologically separated, labelled field data before deployment.
- The frontend production build could not be verified in this Linux review environment because the uploaded `node_modules` contains Windows-specific optional Rollup binaries. Run `npm install` and `npm run build` on the Windows development machine.
- The original uploaded `.env` was excluded from this updated archive to avoid redistributing secrets. Use `.env.example` and set your own values.
