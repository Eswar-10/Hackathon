import mongoose from 'mongoose';

const organizationSettingsSchema = new mongoose.Schema({
  orgName: { type: String, default: 'AquaSense AI Enterprise' },
  defaultLpcdTarget: { type: Number, default: 135 },
  defaultNightFlowThresholdPct: { type: Number, default: 30 },
  alertEmailNotifications: { type: Boolean, default: true },
  unitPreference: { type: String, enum: ['Litres', 'Kilolitres', 'CubicMeters'], default: 'Litres' },
  updatedBy: { type: String, default: 'Admin' }
}, { timestamps: true });

export default mongoose.model('OrganizationSettings', organizationSettingsSchema);
