import mongoose from 'mongoose';

const forecastResultSchema = new mongoose.Schema({
  building_id: { type: String, required: true, index: true },
  generatedAt: { type: Date, default: Date.now },
  modelType: { type: String, default: 'Ridge Regression Time-Series' },
  daysAhead: { type: Number, default: 7 },
  metrics: {
    mae: { type: Number, default: 0 },
    rmse: { type: Number, default: 0 },
    baseline_mae: { type: Number, default: 0 },
    baseline_rmse: { type: Number, default: 0 },
    improvement_pct: { type: Number, default: 0 }
  },
  forecast: [{
    date: String,
    predicted_consumption: Number,
    lower_bound: Number,
    upper_bound: Number,
    day_name: String
  }],
  evaluation: [{
    date: String,
    actual: Number,
    predicted_ml: Number,
    predicted_baseline: Number
  }]
}, { timestamps: true });

export default mongoose.model('ForecastResult', forecastResultSchema);
