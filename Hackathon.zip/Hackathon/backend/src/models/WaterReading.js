import mongoose from 'mongoose';

const waterReadingSchema = new mongoose.Schema({
  timestamp: { type: Date, required: true, index: true },
  building_id: { type: String, required: true, index: true },
  consumption_litres: { type: Number, required: true, min: 0 },
  occupancy: { type: Number, default: 100 },
  building_type: { type: String, default: 'College' },
  meter_id: { type: String, default: 'MTR-001' },
  is_anomaly: { type: Boolean, default: false },
  anomaly_severity: { type: String, enum: ['None', 'Low', 'Medium', 'High', 'Critical'], default: 'None' },
  source: { type: String, enum: ['CSV_Import', 'Manual_Entry', 'Simulated', 'Meter_API', 'Meter_Gateway', 'Live_Meter'], default: 'CSV_Import' },
  import_id: { type: mongoose.Schema.Types.ObjectId, ref: 'DataImport' }
}, { timestamps: true });

// Compound index for fast queries by building and date range
waterReadingSchema.index({ building_id: 1, timestamp: -1 });

export default mongoose.model('WaterReading', waterReadingSchema);
