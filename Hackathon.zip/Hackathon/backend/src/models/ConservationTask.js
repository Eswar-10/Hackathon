import mongoose from 'mongoose';

const conservationTaskSchema = new mongoose.Schema({
  task_id: { type: String, required: true, unique: true, index: true },
  alert_id: { type: String, required: true, index: true },
  building_id: { type: String, required: true, index: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  priority: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'], default: 'Medium' },
  status: { 
    type: String, 
    enum: ['Open', 'Assigned', 'In Progress', 'Resolved', 'Closed'], 
    default: 'Open' 
  },
  assignedTo: { type: String, default: null },
  assignedByName: { type: String, default: 'System Admin' },
  createdBy: { type: String, required: true },
  inspectionFindings: { type: String, default: '' },
  actionTaken: { type: String, default: '' },
  preActionBaselineLitres: { type: Number, default: 0 },
  postActionObservedLitres: { type: Number, default: 0 },
  verifiedSavingsLitres: { type: Number, default: 0 },
  verifiedDate: { type: Date, default: null }
}, { timestamps: true });

export default mongoose.model('ConservationTask', conservationTaskSchema);
