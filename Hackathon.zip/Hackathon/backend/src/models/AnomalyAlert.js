import mongoose from 'mongoose';

const anomalyAlertSchema = new mongoose.Schema({
  alert_id: { type: String, required: true, unique: true, index: true },
  building_id: { type: String, required: true, index: true },
  timestamp: { type: Date, required: true },
  observed_consumption: { type: Number, required: true },
  expected_consumption: { type: Number, required: true },
  absolute_deviation: { type: Number, required: true },
  percentage_deviation: { type: Number, required: true },
  severity: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'], required: true },
  anomaly_type: { type: String, default: 'Possible leakage' },
  contributing_factors: [{ type: String }],
  recommended_action: { type: String, required: true },
  detection_method: { type: String, enum: ['hybrid', 'rules', 'python-hybrid', 'node-rules-fallback'], default: 'rules' },
  isolation_forest_flagged: { type: Boolean, default: false },
  ml_available: { type: Boolean, default: false },
  rule_flags: [{ type: String }],
  data_quality_status: { type: String, enum: ['valid', 'warning', 'invalid'], default: 'valid' },
  confidence_score: { type: Number, min: 0, max: 100, default: null },
  status: { 
    type: String, 
    enum: ['Open', 'Assigned', 'In Progress', 'Resolved', 'Closed'], 
    default: 'Open' 
  },
  assignedTo: { type: String, default: null },
  assignedToName: { type: String, default: null },
  resolutionNotes: { type: String, default: null }
}, { timestamps: true });

export default mongoose.model('AnomalyAlert', anomalyAlertSchema);
