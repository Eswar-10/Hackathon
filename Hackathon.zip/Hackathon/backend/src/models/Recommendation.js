import mongoose from 'mongoose';

const recommendationSchema = new mongoose.Schema({
  building_id: { type: String, required: true, index: true },
  problem: { type: String, required: true },
  evidence: { type: String, required: true },
  suggested_action: { type: String, required: true },
  priority: { type: String, enum: ['Low', 'Medium', 'High', 'Critical'], default: 'Medium' },
  estimated_potential_savings_litres: { type: Number, default: 0 },
  assumptions: { type: String, default: 'Based on 24-hour baseline deviation' },
  verification_method: { type: String, default: 'Compare 7-day average post-action' },
  status: { type: String, enum: ['Active', 'Implemented', 'Dismissed'], default: 'Active' }
}, { timestamps: true });

export default mongoose.model('Recommendation', recommendationSchema);
