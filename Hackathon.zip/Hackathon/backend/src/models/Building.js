import mongoose from 'mongoose';

const buildingSchema = new mongoose.Schema({
  building_id: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true },
  building_type: { 
    type: String, 
    enum: ['College', 'Apartment', 'Commercial', 'Industrial', 'General'], 
    default: 'College' 
  },
  address: { type: String, default: 'Campus Location' },
  occupantCount: { type: Number, default: 100 },
  occupiedRooms: { type: Number, default: 80 },
  totalRooms: { type: Number, default: 100 },
  areaSqFt: { type: Number, default: 25000 },
  baselineThresholds: {
    expectedDailyLitres: { type: Number, default: 5000 },
    lpcdTarget: { type: Number, default: 135 }, // Litres Per Capita per Day standard benchmark
    maxNightFlowLitres: { type: Number, default: 300 },
    anomalyThresholdPct: { type: Number, default: 30 }
  }
}, { timestamps: true });

export default mongoose.model('Building', buildingSchema);
