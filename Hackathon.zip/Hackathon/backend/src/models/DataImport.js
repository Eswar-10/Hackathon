import mongoose from 'mongoose';

const DataImportSchema = new mongoose.Schema({
  fileName: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  totalRows: { type: Number, required: true },
  acceptedRows: { type: Number, required: true },
  rejectedRows: { type: Number, required: true },
  errorLogs: [
    {
      row: Number,
      reason: String
    }
  ],
  importedBy: { type: String, default: 'Facility Manager' },
  status: {
    type: String,
    enum: ['Success', 'Partial', 'Failed'],
    default: 'Success'
  }
}, { timestamps: true });

export default mongoose.model('DataImport', DataImportSchema);
