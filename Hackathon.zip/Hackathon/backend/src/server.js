import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

import { connectDB } from './config/db.js';
import { seedDatabase } from './utils/seedData.js';

import authRoutes from './routes/authRoutes.js';
import buildingRoutes from './routes/buildingRoutes.js';
import readingRoutes from './routes/readingRoutes.js';
import importRoutes from './routes/importRoutes.js';
import anomalyRoutes from './routes/anomalyRoutes.js';
import forecastRoutes from './routes/forecastRoutes.js';
import comparisonRoutes from './routes/comparisonRoutes.js';
import taskRoutes from './routes/taskRoutes.js';
import recommendationRoutes from './routes/recommendationRoutes.js';
import reportRoutes from './routes/reportRoutes.js';
import userRoutes from './routes/userRoutes.js';
import settingsRoutes from './routes/settingsRoutes.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// CORS setup
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// REST API Endpoints
app.use('/api/auth', authRoutes);
app.use('/api/buildings', buildingRoutes);
app.use('/api/readings', readingRoutes);
app.use('/api/imports', importRoutes);
app.use('/api/anomalies', anomalyRoutes);
app.use('/api/forecasts', forecastRoutes);
app.use('/api/comparison', comparisonRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/recommendations', recommendationRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/users', userRoutes);
app.use('/api/settings', settingsRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'AquaSense AI Node.js Backend API',
    timestamp: new Date().toISOString()
  });
});

// Seed trigger endpoint for manual reset
app.post('/api/seed', async (req, res) => {
  try {
    await seedDatabase();
    res.json({ message: 'Database re-seeded successfully with demo data' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Centralized error handling middleware
app.use((err, req, res, next) => {
  console.error('[ServerError]', err.stack);
  res.status(err.status || 500).json({
    message: err.message || 'Internal Server Error',
    error: process.env.NODE_ENV === 'production' ? {} : err
  });
});

// Start Server
const startServer = async () => {
  await connectDB();
  await seedDatabase(); // Ensure DB is seeded on startup for instant full data demonstration

  app.listen(PORT, () => {
    console.log(`===================================================`);
    console.log(` AquaSense AI Backend API is running on port ${PORT}`);
    console.log(` Health Check: http://localhost:${PORT}/api/health`);
    console.log(`===================================================`);
  });
};

startServer();
