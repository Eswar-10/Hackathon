import mongoose from 'mongoose';
import User from '../models/User.js';
import Building from '../models/Building.js';
import WaterReading from '../models/WaterReading.js';
import AnomalyAlert from '../models/AnomalyAlert.js';
import ConservationTask from '../models/ConservationTask.js';
import OrganizationSettings from '../models/OrganizationSettings.js';
import { connectDB } from '../config/db.js';

export const seedDatabase = async () => {
  try {
    console.log('[Seed] Seeding database with initial demo users, buildings, and readings...');

    // 1. Seed Users
    await User.deleteMany({});
    const users = await User.create([
      {
        name: 'Alex Mercer (Admin)',
        email: 'admin@aquasense.ai',
        password: 'admin123',
        role: 'Administrator',
        department: 'Executive Operations',
        buildingIds: ['BLDG-001', 'BLDG-002', 'BLDG-003']
      },
      {
        name: 'Sarah Jenkins (Facility Mgr)',
        email: 'facility@aquasense.ai',
        password: 'facility123',
        role: 'Facility Manager',
        department: 'Campus Facilities',
        buildingIds: ['BLDG-001', 'BLDG-002']
      },
      {
        name: 'David Chen (Auditor)',
        email: 'viewer@aquasense.ai',
        password: 'viewer123',
        role: 'Viewer',
        department: 'Sustainability Council',
        buildingIds: ['BLDG-001']
      }
    ]);

    console.log(`[Seed] Created ${users.length} demo users (admin, facility manager, viewer).`);

    // 2. Seed Buildings
    await Building.deleteMany({});
    const buildings = await Building.create([
      {
        building_id: 'BLDG-001',
        name: 'Engineering Complex Block A',
        building_type: 'College',
        address: 'North Campus Quad 4',
        occupantCount: 350,
        occupiedRooms: 85,
        totalRooms: 100,
        areaSqFt: 45000,
        baselineThresholds: { expectedDailyLitres: 18000, lpcdTarget: 135, maxNightFlowLitres: 400, anomalyThresholdPct: 30 }
      },
      {
        building_id: 'BLDG-002',
        name: 'Oakwood Residency Towers B',
        building_type: 'Apartment',
        address: 'Sector 14 West Wing',
        occupantCount: 240,
        occupiedRooms: 60,
        totalRooms: 64,
        areaSqFt: 32000,
        baselineThresholds: { expectedDailyLitres: 24000, lpcdTarget: 150, maxNightFlowLitres: 500, anomalyThresholdPct: 25 }
      },
      {
        building_id: 'BLDG-003',
        name: 'Innovate Tech Park Plaza C',
        building_type: 'Commercial',
        address: 'Cyber Hub Building 9',
        occupantCount: 450,
        occupiedRooms: 120,
        totalRooms: 120,
        areaSqFt: 60000,
        baselineThresholds: { expectedDailyLitres: 15000, lpcdTarget: 90, maxNightFlowLitres: 200, anomalyThresholdPct: 35 }
      }
    ]);

    console.log(`[Seed] Created ${buildings.length} sample buildings.`);

    // 3. Seed Water Readings
    await WaterReading.deleteMany({});
    const readings = [];

    // Generate 7 days of hourly data for BLDG-001, BLDG-002, BLDG-003
    const bldgs = [
      { id: 'BLDG-001', type: 'College', base: 450, occ: 350 },
      { id: 'BLDG-002', type: 'Apartment', base: 600, occ: 240 },
      { id: 'BLDG-003', type: 'Commercial', base: 350, occ: 450 }
    ];

    const startDate = new Date('2026-10-01T00:00:00Z');

    for (let day = 0; day < 7; day++) {
      for (let hour = 0; hour < 24; hour++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(currentDate.getDate() + day);
        currentDate.setHours(hour);

        bldgs.forEach(b => {
          // Add hourly fluctuation pattern
          let factor = 1.0;
          if (hour >= 7 && hour <= 9) factor = 1.8; // morning peak
          else if (hour >= 12 && hour <= 14) factor = 1.4; // lunch peak
          else if (hour >= 18 && hour <= 20) factor = 1.6; // evening peak
          else if (hour >= 23 || hour <= 5) factor = 0.3; // night low

          // Inject anomaly on Day 3 overnight for BLDG-001
          let consumption = b.base * factor + (Math.random() * 40 - 20);
          let isAnomaly = false;
          let severity = 'None';

          if (b.id === 'BLDG-001' && day === 3 && (hour >= 1 && hour <= 5)) {
            consumption = 780; // High night flow leak
            isAnomaly = true;
            severity = 'High';
          }

          readings.push({
            timestamp: currentDate,
            building_id: b.id,
            consumption_litres: Math.round(consumption),
            occupancy: b.occ,
            building_type: b.type,
            meter_id: `MTR-${b.id.slice(-3)}`,
            is_anomaly: isAnomaly,
            anomaly_severity: severity,
            source: 'Simulated'
          });
        });
      }
    }

    await WaterReading.insertMany(readings);
    console.log(`[Seed] Seeded ${readings.length} historical water readings.`);

    // 4. Seed Anomaly Alert
    await AnomalyAlert.deleteMany({});
    const alert = await AnomalyAlert.create({
      alert_id: 'ALT-BLDG-001-1791244800',
      building_id: 'BLDG-001',
      timestamp: new Date('2026-10-04T02:00:00Z'),
      observed_consumption: 780,
      expected_consumption: 140,
      absolute_deviation: 640,
      percentage_deviation: 457.1,
      severity: 'High',
      anomaly_type: 'Possible leakage',
      contributing_factors: [
        'Sustained overnight consumption (possible continuous pipe leak or running toilet)',
        'High deviation (+457.1%) above historical baseline (140L expected vs 780L observed)'
      ],
      recommended_action: 'Inspect building main shutoff valve and check restrooms for running flappers.',
      status: 'In Progress',
      assignedTo: users[1]._id.toString(),
      assignedToName: users[1].name
    });

    // 5. Seed Conservation Task (Alert-to-Action-to-Verification Workflow)
    await ConservationTask.deleteMany({});
    await ConservationTask.create({
      task_id: 'TSK-1001',
      alert_id: alert.alert_id,
      building_id: 'BLDG-001',
      title: 'Inspect Plumbing & Replace Flush Valve in Block A Restrooms',
      description: 'Investigate overnight high flow anomaly detected on Oct 4 at 02:00. Check 2nd floor restrooms.',
      priority: 'High',
      status: 'Resolved',
      assignedTo: users[1]._id.toString(),
      assignedByName: users[1].name,
      createdBy: 'Alex Mercer (Admin)',
      inspectionFindings: 'Replaced faulty flush valve diaphragm in 2nd floor men\'s restroom causing continuous 500L/hr leakage.',
      actionTaken: 'Replaced internal valve washer and re-calibrated pressure regulator.',
      preActionBaselineLitres: 18500,
      postActionObservedLitres: 14200,
      verifiedSavingsLitres: 4300,
      verifiedDate: new Date('2026-10-05T14:30:00Z')
    });

    // 6. Organization Settings
    await OrganizationSettings.deleteMany({});
    await OrganizationSettings.create({
      orgName: 'AquaSense AI Enterprise',
      defaultLpcdTarget: 135,
      defaultNightFlowThresholdPct: 30,
      alertEmailNotifications: true,
      unitPreference: 'Litres'
    });

    console.log('[Seed] Database seeding completed successfully!');
  } catch (error) {
    console.error('[Seed] Error seeding database:', error);
  }
};
