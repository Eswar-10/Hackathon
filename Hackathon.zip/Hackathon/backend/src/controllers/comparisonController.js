import Building from '../models/Building.js';
import WaterReading from '../models/WaterReading.js';

export const getBuildingComparison = async (req, res) => {
  try {
    const buildings = await Building.find().sort({ building_id: 1 }).lean();
    const comparisonResults = [];

    for (const bldg of buildings) {
      const readings = await WaterReading.find({ building_id: bldg.building_id });
      const totalLitres = readings.reduce((acc, curr) => acc + curr.consumption_litres, 0);
      
      const uniqueDays = new Set(readings.map(r => r.timestamp ? r.timestamp.toISOString().split('T')[0] : ''));
      const daysCount = Math.max(uniqueDays.size, 1);
      const avgDailyLitres = totalLitres / daysCount;

      const occupants = bldg.occupantCount || 100;
      const lpcd = avgDailyLitres / occupants; // Litres Per Capita per Day
      const targetLpcd = bldg.baselineThresholds ? bldg.baselineThresholds.lpcdTarget : 135;

      // Data completeness indicator
      const expectedRecordCount = daysCount * 24;
      const completenessPct = Math.min(100, Math.round((readings.length / Math.max(expectedRecordCount, 1)) * 100));

      let complianceStatus = 'Optimal';
      if (lpcd > targetLpcd * 1.3) complianceStatus = 'High Excess';
      else if (lpcd > targetLpcd) complianceStatus = 'Moderate Excess';

      comparisonResults.push({
        building_id: bldg.building_id,
        name: bldg.name,
        building_type: bldg.building_type,
        occupantCount: occupants,
        occupiedRooms: bldg.occupiedRooms || 80,
        totalLitres: Math.round(totalLitres),
        avgDailyLitres: Math.round(avgDailyLitres),
        lpcd: Math.round(lpcd),
        targetLpcd,
        complianceStatus,
        completenessPct,
        readingsCount: readings.length
      });
    }

    res.json(comparisonResults);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
