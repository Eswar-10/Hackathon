import Building from '../models/Building.js';
import AuditLog from '../models/AuditLog.js';

export const getBuildings = async (req, res) => {
  try {
    const buildings = await Building.find().sort({ building_id: 1 });
    res.json(buildings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getBuildingById = async (req, res) => {
  try {
    const building = await Building.findOne({ building_id: req.params.id });
    if (!building) {
      return res.status(404).json({ message: 'Building not found' });
    }
    res.json(building);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createBuilding = async (req, res) => {
  try {
    const existing = await Building.findOne({ building_id: req.body.building_id });
    if (existing) {
      return res.status(400).json({ message: 'Building ID already exists' });
    }

    const building = await Building.create(req.body);

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'CREATE_BUILDING',
        targetEntity: 'Building',
        entityId: building.building_id
      });
    }

    res.status(201).json(building);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateBuilding = async (req, res) => {
  try {
    const building = await Building.findOneAndUpdate(
      { building_id: req.params.id },
      req.body,
      { new: true }
    );
    if (!building) {
      return res.status(404).json({ message: 'Building not found' });
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'UPDATE_BUILDING',
        targetEntity: 'Building',
        entityId: building.building_id
      });
    }

    res.json(building);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deleteBuilding = async (req, res) => {
  try {
    const building = await Building.findOneAndDelete({ building_id: req.params.id });
    if (!building) {
      return res.status(404).json({ message: 'Building not found' });
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'DELETE_BUILDING',
        targetEntity: 'Building',
        entityId: req.params.id
      });
    }

    res.json({ message: 'Building removed successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
