import WaterReading from '../models/WaterReading.js';
import Building from '../models/Building.js';
import AuditLog from '../models/AuditLog.js';

export const getReadings = async (req, res) => {
  try {
    const { building_id, startDate, endDate, limit = 500, page = 1, source } = req.query;
    const query = {};

    if (building_id && building_id !== 'ALL') {
      query.building_id = building_id;
    }
    if (source && source !== 'ALL') {
      query.source = source;
    }
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const total = await WaterReading.countDocuments(query);
    const readings = await WaterReading.find(query)
      .sort({ timestamp: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({
      total,
      page: Number(page),
      pages: Math.ceil(total / limit),
      readings
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createReading = async (req, res) => {
  try {
    const { timestamp, building_id, consumption_litres, occupancy, building_type, meter_id } = req.body;

    if (!timestamp || !building_id || consumption_litres === undefined) {
      return res.status(400).json({ message: 'timestamp, building_id, and consumption_litres are required' });
    }

    if (consumption_litres < 0) {
      return res.status(400).json({ message: 'Consumption cannot be negative' });
    }

    const reading = await WaterReading.create({
      timestamp: new Date(timestamp),
      building_id,
      consumption_litres: Number(consumption_litres),
      occupancy: occupancy ? Number(occupancy) : 100,
      building_type: building_type || 'College',
      meter_id: meter_id || 'MTR-MANUAL',
      source: 'Manual_Entry'
    });

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'MANUAL_READING_ADD',
        targetEntity: 'WaterReading',
        entityId: reading._id.toString(),
        metadata: { building_id, consumption_litres, timestamp }
      });
    }

    res.status(201).json(reading);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateReading = async (req, res) => {
  try {
    const oldReading = await WaterReading.findById(req.params.id);
    if (!oldReading) {
      return res.status(404).json({ message: 'Reading not found' });
    }

    const updatedReading = await WaterReading.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'MANUAL_READING_EDIT',
        targetEntity: 'WaterReading',
        entityId: req.params.id,
        metadata: {
          previousConsumption: oldReading.consumption_litres,
          newConsumption: updatedReading.consumption_litres
        }
      });
    }

    res.json(updatedReading);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deleteReading = async (req, res) => {
  try {
    const reading = await WaterReading.findByIdAndDelete(req.params.id);
    if (!reading) {
      return res.status(404).json({ message: 'Reading not found' });
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'MANUAL_READING_DELETE',
        targetEntity: 'WaterReading',
        entityId: req.params.id,
        metadata: { building_id: reading.building_id, timestamp: reading.timestamp }
      });
    }

    res.json({ message: 'Reading deleted with audit log' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getDashboardSummary = async (req, res) => {
  try {
    const { building_id } = req.query;
    const matchQuery = {};
    if (building_id && building_id !== 'ALL') {
      matchQuery.building_id = building_id;
    }

    const readings = await WaterReading.find(matchQuery).sort({ timestamp: -1 });
    const totalConsumption = readings.reduce((acc, curr) => acc + curr.consumption_litres, 0);

    // Calculate daily average
    const uniqueDates = new Set(readings.map(r => r.timestamp ? r.timestamp.toISOString().split('T')[0] : ''));
    const daysCount = Math.max(uniqueDates.size, 1);
    const avgDailyConsumption = totalConsumption / daysCount;

    // Calculate LPCD (litres per capita per day)
    const buildings = await Building.find();
    let totalOccupants = buildings.reduce((acc, b) => acc + (b.occupantCount || 100), 0);
    if (building_id && building_id !== 'ALL') {
      const targetBldg = buildings.find(b => b.building_id === building_id);
      totalOccupants = targetBldg ? targetBldg.occupantCount : 100;
    }
    const lpcd = avgDailyConsumption / Math.max(totalOccupants, 1);

    // Estimated water savings (15% benchmark reduction from optimized anomaly fixing)
    const estimatedSavingsLitres = Math.round(totalConsumption * 0.14);

    res.json({
      totalConsumptionLitres: Math.round(totalConsumption),
      avgDailyConsumptionLitres: Math.round(avgDailyConsumption),
      lpcd: Math.round(lpcd),
      estimatedSavingsLitres,
      totalReadingsCount: readings.length,
      daysCount,
      lastUpdated: readings.length > 0 ? readings[0].timestamp : new Date()
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
