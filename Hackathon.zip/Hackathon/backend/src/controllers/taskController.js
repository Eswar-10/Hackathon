import ConservationTask from '../models/ConservationTask.js';
import AnomalyAlert from '../models/AnomalyAlert.js';
import WaterReading from '../models/WaterReading.js';
import AuditLog from '../models/AuditLog.js';

export const getTasks = async (req, res) => {
  try {
    const { building_id, status, priority } = req.query;
    const query = {};
    if (building_id && building_id !== 'ALL') query.building_id = building_id;
    if (status && status !== 'ALL') query.status = status;
    if (priority && priority !== 'ALL') query.priority = priority;

    const tasks = await ConservationTask.find(query).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createTask = async (req, res) => {
  try {
    const { alert_id, building_id, title, description, priority, assignedTo, assignedByName } = req.body;

    if (!building_id || !title) {
      return res.status(400).json({ message: 'building_id and title are required' });
    }

    const taskId = `TSK-${Date.now()}`;
    const task = await ConservationTask.create({
      task_id: taskId,
      alert_id: alert_id || `ALT-MANUAL-${Date.now()}`,
      building_id,
      title,
      description: description || 'Investigate potential water leakage and perform maintenance.',
      priority: priority || 'Medium',
      assignedTo: assignedTo || null,
      assignedByName: assignedByName || 'Unassigned',
      createdBy: req.user ? req.user.name : 'Facility Manager',
      status: assignedTo ? 'Assigned' : 'Open'
    });

    // Update corresponding alert status if linked
    if (alert_id) {
      await AnomalyAlert.findOneAndUpdate(
        { alert_id },
        { status: 'Assigned', assignedTo, assignedToName: assignedByName }
      );
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'CREATE_CONSERVATION_TASK',
        targetEntity: 'ConservationTask',
        entityId: task.task_id,
        metadata: { alert_id, building_id, assignedTo }
      });
    }

    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateTaskStatus = async (req, res) => {
  try {
    const { status, inspectionFindings, actionTaken, assignedTo, assignedByName } = req.body;
    const task = await ConservationTask.findOne({ task_id: req.params.id });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    if (status) task.status = status;
    if (inspectionFindings !== undefined) task.inspectionFindings = inspectionFindings;
    if (actionTaken !== undefined) task.actionTaken = actionTaken;
    if (assignedTo !== undefined) task.assignedTo = assignedTo;
    if (assignedByName !== undefined) task.assignedByName = assignedByName;

    await task.save();

    // Update alert status sync
    if (task.alert_id) {
      await AnomalyAlert.findOneAndUpdate(
        { alert_id: task.alert_id },
        { status: task.status }
      );
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'UPDATE_TASK_STATUS',
        targetEntity: 'ConservationTask',
        entityId: task.task_id,
        metadata: { status: task.status, inspectionFindings }
      });
    }

    res.json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const verifyTaskImpact = async (req, res) => {
  try {
    const task = await ConservationTask.findOne({ task_id: req.params.id });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // Fetch water readings for this building
    const readings = await WaterReading.find({ building_id: task.building_id }).sort({ timestamp: -1 });

    if (readings.length === 0) {
      return res.status(400).json({ message: 'No water readings available to compare pre/post impact' });
    }

    // Calculate Pre-Action Baseline (average daily consumption before task resolution)
    const preActionBaseline = task.preActionBaselineLitres > 0 
      ? task.preActionBaselineLitres 
      : 5500;

    // Calculate Post-Action Consumption (most recent 24-48 hours reading average)
    const recentReadings = readings.slice(0, Math.min(readings.length, 24));
    const recentSum = recentReadings.reduce((acc, curr) => acc + curr.consumption_litres, 0);
    const postActionObserved = recentReadings.length > 0 ? Math.round(recentSum / Math.max(recentReadings.length / 24, 1)) : 4100;

    const verifiedSavings = Math.max(0, preActionBaseline - postActionObserved);

    task.preActionBaselineLitres = preActionBaseline;
    task.postActionObservedLitres = postActionObserved;
    task.verifiedSavingsLitres = verifiedSavings;
    task.status = 'Resolved';
    task.verifiedDate = new Date();
    await task.save();

    // Also update alert
    if (task.alert_id) {
      await AnomalyAlert.findOneAndUpdate({ alert_id: task.alert_id }, { status: 'Resolved' });
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'VERIFY_CONSERVATION_TASK',
        targetEntity: 'ConservationTask',
        entityId: task.task_id,
        metadata: { preActionBaseline, postActionObserved, verifiedSavings }
      });
    }

    res.json({
      message: 'Post-action consumption verified against baseline successfully',
      task,
      verificationSummary: {
        preActionBaselineLitres: preActionBaseline,
        postActionObservedLitres: postActionObserved,
        verifiedSavingsLitresPerDay: verifiedSavings,
        annualizedSavingsLitres: verifiedSavings * 365,
        estimatedCostSavingsINR: Math.round(verifiedSavings * 365 * 0.08) // ~ 0.08 INR / L benchmark
      }
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
