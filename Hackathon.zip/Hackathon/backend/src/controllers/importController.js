import DataImport from '../models/DataImport.js';
import WaterReading from '../models/WaterReading.js';
import Building from '../models/Building.js';
import AuditLog from '../models/AuditLog.js';
import axios from 'axios';
import multer from 'multer';

const storage = multer.memoryStorage();

// Small RFC-4180-style line parser: supports quoted commas and escaped double quotes.
// Multiline quoted fields are not supported; this import format does not require them.
const parseCSVLine = (line) => {
  const values = [];
  let value = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && quoted && line[i + 1] === '"') {
      value += '"';
      i++;
    } else if (ch === '"') {
      quoted = !quoted;
    } else if (ch === ',' && !quoted) {
      values.push(value.trim());
      value = '';
    } else {
      value += ch;
    }
  }
  values.push(value.trim());
  return values;
};
export const uploadMiddleware = multer({ storage }).single('file');

export const previewCSV = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No CSV file uploaded' });
    }

    const csvText = req.file.buffer.toString('utf-8');
    const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);

    if (lines.length < 2) {
      return res.status(400).json({ message: 'CSV file is empty or missing headers' });
    }

    const headers = parseCSVLine(lines[0]).map(h => h.trim().toLowerCase());
    const reqCols = ['timestamp', 'building_id', 'consumption_litres'];
    const missing = reqCols.filter(col => !headers.includes(col));

    if (missing.length > 0) {
      return res.status(400).json({ 
        message: `CSV missing required headers: ${missing.join(', ')}. Required columns: timestamp, building_id, consumption_litres, occupancy, building_type, meter_id.` 
      });
    }

    const tsIdx = headers.indexOf('timestamp');
    const bldgIdx = headers.indexOf('building_id');
    const consIdx = headers.indexOf('consumption_litres');
    const occIdx = headers.indexOf('occupancy');
    const typeIdx = headers.indexOf('building_type');
    const meterIdx = headers.indexOf('meter_id');

    let acceptedCount = 0;
    let rejectedCount = 0;
    const errors = [];
    const previewRecords = [];
    const seenKeys = new Set();

    for (let i = 1; i < lines.length; i++) {
      const row = parseCSVLine(lines[i]);
      const rowNum = i + 1;

      if (row.length < 3) {
        rejectedCount++;
        errors.append ? errors.push({ row: rowNum, reason: 'Incomplete row data' }) : errors.push({ row: rowNum, reason: 'Incomplete row data' });
        continue;
      }

      const tsStr = row[tsIdx];
      const bldgId = row[bldgIdx];
      const consVal = parseFloat(row[consIdx]);
      const occVal = occIdx !== -1 && row[occIdx] ? parseInt(row[occIdx], 10) : 100;
      const bldgType = typeIdx !== -1 && row[typeIdx] ? row[typeIdx] : 'College';
      const meterId = meterIdx !== -1 && row[meterIdx] ? row[meterIdx] : 'MTR-001';

      // Validation 1: Required identity + timestamp
      const tsDate = new Date(tsStr);
      if (!bldgId) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: 'Missing building_id' });
        continue;
      }
      if (isNaN(tsDate.getTime())) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: `Invalid date timestamp: '${tsStr}'` });
        continue;
      }

      // Validation 2: Non-negative consumption
      if (!Number.isFinite(consVal) || consVal < 0) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: `Invalid consumption value: '${row[consIdx]}' (must be a finite non-negative number)` });
        continue;
      }
      if (occIdx !== -1 && row[occIdx] !== '' && (!Number.isFinite(occVal) || occVal < 0)) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: 'Occupancy must be a non-negative integer when provided' });
        continue;
      }

      // Validation 3: Duplicate check per building + meter + timestamp
      const dupKey = `${bldgId}_${meterId}_${tsDate.toISOString()}`;
      if (seenKeys.has(dupKey)) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: `Duplicate row for building '${bldgId}' at '${tsStr}'` });
        continue;
      }
      seenKeys.add(dupKey);

      acceptedCount++;
      if (previewRecords.length < 50) {
        previewRecords.push({
          timestamp: tsDate.toISOString(),
          building_id: bldgId,
          consumption_litres: consVal,
          occupancy: occVal,
          building_type: bldgType,
          meter_id: meterId
        });
      }
    }

    res.json({
      fileName: req.file.originalname,
      totalRows: lines.length - 1,
      acceptedCount,
      rejectedCount,
      errors,
      previewRecords
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const importCSV = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No CSV file provided for import' });
    }

    const csvText = req.file.buffer.toString('utf-8');
    const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length < 2) {
      return res.status(400).json({ message: 'CSV file is empty or missing data rows' });
    }
    const headers = parseCSVLine(lines[0]).map(h => h.trim().toLowerCase());
    const requiredHeaders = ['timestamp', 'building_id', 'consumption_litres'];
    const missingHeaders = requiredHeaders.filter(header => !headers.includes(header));
    if (missingHeaders.length > 0) {
      return res.status(400).json({ message: `CSV missing required headers: ${missingHeaders.join(', ')}` });
    }

    const tsIdx = headers.indexOf('timestamp');
    const bldgIdx = headers.indexOf('building_id');
    const consIdx = headers.indexOf('consumption_litres');
    const occIdx = headers.indexOf('occupancy');
    const typeIdx = headers.indexOf('building_type');
    const meterIdx = headers.indexOf('meter_id');

    let acceptedCount = 0;
    let rejectedCount = 0;
    const errors = [];
    const validReadings = [];
    const seenKeys = new Set();

    const importDoc = await DataImport.create({
      fileName: req.file.originalname,
      importedBy: req.user ? req.user.name : 'Facility Manager',
      status: 'Partial'
    });

    for (let i = 1; i < lines.length; i++) {
      const row = parseCSVLine(lines[i]);
      const rowNum = i + 1;

      if (row.length < 3) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: 'Incomplete row data' });
        continue;
      }

      const tsStr = row[tsIdx];
      const bldgId = row[bldgIdx];
      const consVal = parseFloat(row[consIdx]);
      const occVal = occIdx !== -1 && row[occIdx] ? parseInt(row[occIdx], 10) : 100;
      const bldgType = typeIdx !== -1 && row[typeIdx] ? row[typeIdx] : 'College';
      const meterId = meterIdx !== -1 && row[meterIdx] ? row[meterIdx] : 'MTR-001';

      const tsDate = new Date(tsStr);
      if (!bldgId || isNaN(tsDate.getTime()) || !Number.isFinite(consVal) || consVal < 0) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: 'Missing building_id or invalid timestamp/consumption value' });
        continue;
      }
      if (occIdx !== -1 && row[occIdx] !== '' && (!Number.isFinite(occVal) || occVal < 0)) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: 'Occupancy must be a non-negative integer when provided' });
        continue;
      }

      const dupKey = `${bldgId}_${meterId}_${tsDate.toISOString()}`;
      if (seenKeys.has(dupKey)) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: `Duplicate row for ${bldgId}/${meterId} at ${tsStr}` });
        continue;
      }
      seenKeys.add(dupKey);

      // Check DB for an existing reading from this same meter at this timestamp.
      const existing = await WaterReading.findOne({ building_id: bldgId, meter_id: meterId, timestamp: tsDate });
      if (existing) {
        rejectedCount++;
        errors.push({ row: rowNum, reason: `Record already exists in DB for ${bldgId} at ${tsStr}` });
        continue;
      }

      validReadings.push({
        timestamp: tsDate,
        building_id: bldgId,
        consumption_litres: consVal,
        occupancy: occVal,
        building_type: bldgType,
        meter_id: meterId,
        source: 'CSV_Import',
        import_id: importDoc._id
      });
      acceptedCount++;
    }

    if (validReadings.length > 0) {
      await WaterReading.insertMany(validReadings);
      
      // Auto-ensure building exists
      const uniqueBldgs = [...new Set(validReadings.map(r => r.building_id))];
      for (const bId of uniqueBldgs) {
        const found = await Building.findOne({ building_id: bId });
        if (!found) {
          const sampleReading = validReadings.find(r => r.building_id === bId);
          await Building.create({
            building_id: bId,
            name: `Building ${bId}`,
            building_type: sampleReading ? sampleReading.building_type : 'College',
            occupantCount: sampleReading ? sampleReading.occupancy : 100
          });
        }
      }
    }

    importDoc.totalRows = lines.length - 1;
    importDoc.acceptedRows = acceptedCount;
    importDoc.rejectedRows = rejectedCount;
    importDoc.errorLogs = errors;
    importDoc.status = rejectedCount === 0 ? 'Success' : (acceptedCount > 0 ? 'Partial' : 'Failed');
    await importDoc.save();

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'CSV_IMPORT',
        targetEntity: 'DataImport',
        entityId: importDoc._id.toString(),
        metadata: { fileName: req.file.originalname, acceptedCount, rejectedCount }
      });
    }

    res.json({
      message: 'CSV import processed successfully',
      importDoc
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getImportHistory = async (req, res) => {
  try {
    const history = await DataImport.find().sort({ timestamp: -1 });
    res.json(history);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const downloadCSVTemplate = (req, res) => {
  const template = `timestamp,building_id,building_type,meter_id,consumption_litres,occupancy\n2026-10-01 08:00:00,BLDG-001,College,MTR-101,1250,500\n2026-10-01 09:00:00,BLDG-001,College,MTR-101,1420,500\n`;
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="aquasense_water_reading_template.csv"');
  res.send(template);
};
