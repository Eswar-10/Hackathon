import WaterReading from '../models/WaterReading.js';
import AnomalyAlert from '../models/AnomalyAlert.js';
import Building from '../models/Building.js';
import AuditLog from '../models/AuditLog.js';
import axios from 'axios';

// Deterministic rules-only fallback. It deliberately does not pretend to run ML.
const detectAnomaliesNodeFallback = (readings, threshold_pct = 30, buildingById = new Map()) => {
  if (!Array.isArray(readings) || readings.length === 0) return [];
  const groups = new Map();
  for (const reading of readings) {
    const key = `${reading.building_id}::${reading.meter_id || 'UNKNOWN-METER'}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(reading);
  }

  const alerts = [];
  for (const list of groups.values()) {
    list.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    for (let i = 3; i < list.length; i++) {
      const reading = list[i];
      const observed = Number(reading.consumption_litres);
      const previous = list.slice(Math.max(0, i - 24), i)
        .map(item => Number(item.consumption_litres))
        .filter(value => Number.isFinite(value) && value >= 0);
      if (!Number.isFinite(observed) || observed < 0 || previous.length < 3) continue;
      const sorted = [...previous].sort((a, b) => a - b);
      const mid = Math.floor(sorted.length / 2);
      const expected = sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
      const deviation = observed - expected;
      const devPct = deviation / Math.max(expected, 1) * 100;
      const hour = new Date(reading.timestamp).getHours();
      const overnight = hour >= 23 || hour <= 5;
      const limits = buildingById.get(reading.building_id)?.baselineThresholds || {};
      const nightLimit = Number(limits.maxNightFlowLitres);
      const nightLimitBreach = overnight && Number.isFinite(nightLimit) && nightLimit > 0 && observed > nightLimit;
      const deviationRule = devPct >= Number(threshold_pct) && deviation >= 50;
      const overnightRule = overnight && devPct >= Math.max(20, Number(threshold_pct) * 0.75) && deviation >= 30;
      const persistentRule = previous.slice(-2).length === 2 && previous.slice(-2).every(v => v > expected * 1.25) && observed > expected * 1.25;
      const ruleFlags = [];
      if (nightLimitBreach) ruleFlags.push('Configured overnight-flow safeguard breached');
      if (deviationRule) ruleFlags.push('Consumption exceeds the configured percentage and absolute-deviation thresholds');
      if (overnightRule) ruleFlags.push('Elevated overnight consumption compared with prior baseline');
      if (persistentRule) ruleFlags.push('Elevated consumption persisted across three consecutive readings');
      if (!ruleFlags.length) continue;

      let severity = 'Low';
      if (nightLimitBreach || devPct >= 100 || deviation >= Math.max(expected * 2, 250)) severity = 'Critical';
      else if (devPct >= 60 || persistentRule) severity = 'High';
      else if (devPct >= Number(threshold_pct) || overnightRule) severity = 'Medium';

      const factors = [...ruleFlags, `Observed ${observed.toFixed(1)} L vs prior baseline ${expected.toFixed(1)} L (${devPct >= 0 ? '+' : ''}${devPct.toFixed(1)}%)`];
      if (overnight) factors.push('Reading occurred during the overnight window; investigate before diagnosing a leak');
      alerts.push({
        timestamp: new Date(reading.timestamp).toISOString(),
        building_id: reading.building_id,
        building_type: reading.building_type || 'General',
        meter_id: reading.meter_id || 'UNKNOWN-METER',
        observed_consumption: Number(observed.toFixed(2)),
        expected_consumption: Number(expected.toFixed(2)),
        absolute_deviation: Number(deviation.toFixed(2)),
        percentage_deviation: Number(devPct.toFixed(2)),
        severity,
        anomaly_type: (overnightRule || persistentRule || nightLimitBreach) ? 'Possible leakage' : 'Unusual consumption',
        contributing_factors: factors,
        recommended_action: severity === 'High' || severity === 'Critical'
          ? 'Verify the meter reading, inspect relevant shutoff valves and plumbing, and compare nearby sub-meters before taking corrective action.'
          : 'Review occupancy and scheduled water use, then compare this meter with recent readings before dispatching maintenance.',
        isolation_forest_flagged: false,
        ml_available: false,
        detection_method: 'rules',
        rule_flags: ruleFlags,
        data_quality_status: 'valid',
        confidence_score: null
      });
    }
  }
  return alerts;
};

export const runAnomalyDetection = async (req, res) => {
  try {
    const { building_id, threshold_pct = 30 } = req.body;
    const query = {};
    if (building_id && building_id !== 'ALL') {
      query.building_id = building_id;
    }

    const readings = await WaterReading.find(query).sort({ timestamp: 1 }).lean();
    if (readings.length === 0) {
      return res.json({ message: 'No water readings found to analyze', anomalies: [] });
    }

    let anomalies = [];
    let dataQuality = null;
    let detectionEngine = 'python-hybrid';
    const pyUrl = process.env.ANALYTICS_SERVICE_URL || 'http://localhost:8000';

    // Supply building-specific safeguards when configured. These values are limits,
    // not universal assumptions; missing configuration is deliberately left unset.
    const buildingIds = [...new Set(readings.map(r => r.building_id))];
    const buildingDocs = await Building.find({ building_id: { $in: buildingIds } }).lean();
    const buildingById = new Map(buildingDocs.map(b => [b.building_id, b]));
    const analyticsReadings = readings.map(r => {
      const building = buildingById.get(r.building_id);
      const limits = building?.baselineThresholds || {};
      return {
        timestamp: r.timestamp instanceof Date ? r.timestamp.toISOString() : new Date(r.timestamp).toISOString(),
        building_id: r.building_id,
        meter_id: r.meter_id || 'UNKNOWN-METER',
        source: r.source || 'Unknown',
        consumption_litres: r.consumption_litres,
        occupancy: r.occupancy,
        building_type: r.building_type || building?.building_type || 'General',
        max_night_flow_litres: limits.maxNightFlowLitres,
      };
    });

    try {
      const pyRes = await axios.post(`${pyUrl}/detect-anomalies`, {
        readings: analyticsReadings,
        threshold_pct: Number(threshold_pct)
      }, { timeout: 10000 });

      if (pyRes.data && Array.isArray(pyRes.data.anomalies)) {
        anomalies = pyRes.data.anomalies;
        dataQuality = pyRes.data.data_quality || null;
      } else {
        throw new Error('Analytics service returned an invalid anomaly response');
      }
    } catch (pyErr) {
      console.log('[AnomalyEngine] Python service unavailable, using Node rules fallback:', pyErr.message);
      detectionEngine = 'node-rules-fallback';
      anomalies = detectAnomaliesNodeFallback(readings, Number(threshold_pct), buildingById);
    }

    // Save detected anomalies into AnomalyAlert collection without duplicates
    const savedAlerts = [];
    for (const a of anomalies) {
      const alertId = `ALT-${a.building_id}-${new Date(a.timestamp).getTime()}`;
      const existing = await AnomalyAlert.findOne({ alert_id: alertId });
      
      if (!existing) {
        const newAlert = await AnomalyAlert.create({
          alert_id: alertId,
          building_id: a.building_id,
          timestamp: new Date(a.timestamp),
          observed_consumption: a.observed_consumption,
          expected_consumption: a.expected_consumption,
          absolute_deviation: a.absolute_deviation,
          percentage_deviation: a.percentage_deviation,
          severity: a.severity,
          anomaly_type: a.anomaly_type,
          contributing_factors: a.contributing_factors,
          recommended_action: a.recommended_action,
          detection_method: a.detection_method || detectionEngine,
          isolation_forest_flagged: Boolean(a.isolation_forest_flagged),
          ml_available: Boolean(a.ml_available),
          rule_flags: Array.isArray(a.rule_flags) ? a.rule_flags : [],
          data_quality_status: a.data_quality_status || 'valid',
          confidence_score: Number.isFinite(a.confidence_score) ? a.confidence_score : null,
          status: 'Open'
        });
        savedAlerts.push(newAlert);
      } else {
        savedAlerts.push(existing);
      }
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'RUN_ANOMALY_DETECTION',
        targetEntity: 'AnomalyAlert',
        metadata: { building_id, totalAnomaliesDetected: anomalies.length }
      });
    }

    res.json({
      status: 'success',
      detectionEngine,
      dataQuality,
      totalAnomaliesDetected: anomalies.length,
      anomalies: savedAlerts
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getAlerts = async (req, res) => {
  try {
    const { building_id, severity, status, search } = req.query;
    const query = {};

    if (building_id && building_id !== 'ALL') query.building_id = building_id;
    if (severity && severity !== 'ALL') query.severity = severity;
    if (status && status !== 'ALL') query.status = status;
    if (search) {
      query.$or = [
        { alert_id: { $regex: search, $options: 'i' } },
        { building_id: { $regex: search, $options: 'i' } },
        { recommended_action: { $regex: search, $options: 'i' } }
      ];
    }

    const alerts = await AnomalyAlert.find(query).sort({ timestamp: -1 });
    res.json(alerts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateAlertStatus = async (req, res) => {
  try {
    const { status, assignedTo, assignedToName, resolutionNotes } = req.body;
    const alert = await AnomalyAlert.findOne({ alert_id: req.params.id });

    if (!alert) {
      return res.status(404).json({ message: 'Alert not found' });
    }

    if (status) alert.status = status;
    if (assignedTo) alert.assignedTo = assignedTo;
    if (assignedToName) alert.assignedToName = assignedToName;
    if (resolutionNotes) alert.resolutionNotes = resolutionNotes;

    await alert.save();

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'UPDATE_ALERT_STATUS',
        targetEntity: 'AnomalyAlert',
        entityId: alert.alert_id,
        metadata: { newStatus: status, assignedTo }
      });
    }

    res.json(alert);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
