import OrganizationSettings from '../models/OrganizationSettings.js';
import AuditLog from '../models/AuditLog.js';

export const getSettings = async (req, res) => {
  try {
    let settings = await OrganizationSettings.findOne();
    if (!settings) {
      settings = await OrganizationSettings.create({});
    }
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateSettings = async (req, res) => {
  try {
    let settings = await OrganizationSettings.findOne();
    if (!settings) {
      settings = await OrganizationSettings.create(req.body);
    } else {
      Object.assign(settings, req.body);
      settings.updatedBy = req.user ? req.user.name : 'Admin';
      await settings.save();
    }

    if (req.user) {
      await AuditLog.create({
        user_id: req.user._id.toString(),
        userName: req.user.name,
        userRole: req.user.role,
        action: 'UPDATE_ORGANIZATION_SETTINGS',
        targetEntity: 'OrganizationSettings',
        entityId: settings._id.toString()
      });
    }

    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
