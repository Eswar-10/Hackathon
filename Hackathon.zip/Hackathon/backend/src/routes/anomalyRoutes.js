import express from 'express';
import { runAnomalyDetection, getAlerts, updateAlertStatus } from '../controllers/anomalyController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/alerts', protect, getAlerts);
router.post('/detect', protect, runAnomalyDetection);
router.put('/alerts/:id', protect, authorize('Administrator', 'Facility Manager'), updateAlertStatus);

export default router;
