import express from 'express';
import { getUsers, updateUserRole, deleteUser } from '../controllers/userController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/', protect, authorize('Administrator'), getUsers);
router.put('/:id/role', protect, authorize('Administrator'), updateUserRole);
router.delete('/:id', protect, authorize('Administrator'), deleteUser);

export default router;
