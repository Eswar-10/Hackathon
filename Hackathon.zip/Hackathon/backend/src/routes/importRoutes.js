import express from 'express';
import { uploadMiddleware, previewCSV, importCSV, getImportHistory, downloadCSVTemplate } from '../controllers/importController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/template', downloadCSVTemplate);
router.get('/history', protect, getImportHistory);
router.post('/preview', protect, uploadMiddleware, previewCSV);
router.post('/upload', protect, authorize('Administrator', 'Facility Manager'), uploadMiddleware, importCSV);

export default router;
