import express from 'express';
import { getReadings, createReading, updateReading, deleteReading, getDashboardSummary } from '../controllers/readingController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/summary', protect, getDashboardSummary);

router.route('/')
  .get(protect, getReadings)
  .post(protect, authorize('Administrator', 'Facility Manager'), createReading);

router.route('/:id')
  .put(protect, authorize('Administrator', 'Facility Manager'), updateReading)
  .delete(protect, authorize('Administrator', 'Facility Manager'), deleteReading);

export default router;
