import express from 'express';
import { getBuildingComparison } from '../controllers/comparisonController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', protect, getBuildingComparison);

export default router;
