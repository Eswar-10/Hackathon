import express from 'express';
import { getTasks, createTask, updateTaskStatus, verifyTaskImpact } from '../controllers/taskController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.route('/')
  .get(protect, getTasks)
  .post(protect, authorize('Administrator', 'Facility Manager'), createTask);

router.put('/:id', protect, authorize('Administrator', 'Facility Manager'), updateTaskStatus);
router.post('/:id/verify', protect, authorize('Administrator', 'Facility Manager'), verifyTaskImpact);

export default router;
