import express from 'express';
import { getBuildings, getBuildingById, createBuilding, updateBuilding, deleteBuilding } from '../controllers/buildingController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.route('/')
  .get(protect, getBuildings)
  .post(protect, authorize('Administrator', 'Facility Manager'), createBuilding);

router.route('/:id')
  .get(protect, getBuildingById)
  .put(protect, authorize('Administrator', 'Facility Manager'), updateBuilding)
  .delete(protect, authorize('Administrator'), deleteBuilding);

export default router;
