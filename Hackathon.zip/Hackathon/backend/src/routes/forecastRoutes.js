import express from 'express';
import { generateForecast, getLatestForecast } from '../controllers/forecastController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/latest', protect, getLatestForecast);
router.post('/generate', protect, generateForecast);

export default router;
