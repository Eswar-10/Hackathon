import express from 'express';
import { getImpactReport } from '../controllers/reportController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', protect, getImpactReport);

export default router;
