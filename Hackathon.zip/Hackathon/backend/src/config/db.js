import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoServer;

export const connectDB = async () => {
  const connUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/aquasense';
  
  try {
    // Attempt local MongoDB connection with 2.5s timeout
    await mongoose.connect(connUri, {
      serverSelectionTimeoutMS: 2500
    });
    console.log(`[Database] Connected to MongoDB at ${connUri}`);
  } catch (err) {
    console.warn(`[Database] Could not connect to local MongoDB (${err.message}). Starting MongoMemoryServer...`);
    try {
      mongoServer = await MongoMemoryServer.create();
      const mongoUri = mongoServer.getUri();
      await mongoose.connect(mongoUri);
      console.log(`[Database] Successfully connected to embedded MongoMemoryServer at ${mongoUri}`);
    } catch (memErr) {
      console.error(`[Database] Failed to start MongoMemoryServer: ${memErr.message}`);
    }
  }
};
